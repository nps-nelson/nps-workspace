---
title: Serverless
description: Learn how Serverless reduces cost usage on Railway.
---

_Note: This feature is formerly called: App-Sleeping_

Serverless allows you to increase the efficiency of resource utilization on Railway and may reduce the usage cost of a [service](/services), by ensuring it is running only when necessary.

## How it works

When Serverless is enabled for a service, Railway automatically detects inactivity based on outbound traffic.

#### Applying the setting

Serverless is applied to a container when that container is created. Enabling it on a running service does not affect the container already running; the service must be deployed before it takes effect.

This applies to the API too. `serviceInstanceUpdate` writes the value and reads it back as set, but the running container keeps the value it was created with until the next deployment.

#### Inactive service detection

Inactivity is based on the detection of any outbound packets, which could include network requests, database connections, or even NTP. Once a service stops sending packets it is considered inactive after 5 minutes. Inactivity is sampled on an interval rather than measured continuously, so in practice a service sleeps somewhere between 5 and 10 minutes after its last outbound traffic.

Some things that can prevent a service from being put to sleep -

- Keeping active database connections open, such as a database connection pooler.
- Frameworks that report telemetry to their respective services, such as [Next.js](https://nextjs.org/telemetry).
- Making requests to other services in the same [project](/overview/the-basics#project--project-canvas) over the [private network](/networking/private-networking).
- Making requests to other Railway services over the public internet.
- Making requests to external services over the public internet.
- Receiving traffic from other services in the same project over the private network.
- Receiving traffic from other Railway services over the public internet.
- Receiving traffic from external services over the public internet.

It's important to note that the networking graph in the metrics tab only displays public internet traffic. If you're using a private network to communicate with other services, this traffic won't appear in the metrics tab. However, it's still counted as outbound traffic and will prevent the service from being put to sleep.

#### Waking a service up

A service is woken when it receives traffic from the internet or from another service in the same project through the [private network](/networking/private-networking).

The first request made to a slept service wakes it. It may take a small amount of time for the service to spin up again on the first request (commonly known as "cold boot time").

## Caveats

- There will be a small delay in the response time of the first request sent to a slept service (commonly known as "cold boot times").
- The first request sent to a slept service may return a 502 Bad Gateway response.
- For Railway to put a service to sleep, a service must not send _outbound_ traffic for at least 5 minutes. Outbound traffic can include telemetry, database connections, NTP, etc. Inbound requests are not measured directly, but anything your service sends in response to them is, so traffic that reaches your service will keep it awake.
- Enabling Serverless will apply the setting across all [Replicas](/deployments/scaling#horizontal-scaling-with-replicas)
- Slept services still consume a slot on Railway's infrastructure, enabling Serverless de-prioritizes your workload and in remote cases, may require a rebuild to re-live the service.

## Support

For information on how to enable Serverless on your services refer to the [how to guide](/pricing/cost-control#enabling-serverless).
