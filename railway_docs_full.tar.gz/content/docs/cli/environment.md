---
title: railway environment
description: Manage environments.
---

Create, delete, edit, or link an environment.

## Usage

```bash
railway environment [ENVIRONMENT] [COMMAND]
```

## Aliases

- `railway env`

## Subcommands

| Subcommand | Aliases | Description |
|------------|---------|-------------|
| `list` | `ls` | List all environments in the project |
| `link` | | Link an environment to the current project |
| `new` | `create`, `add` | Create a new environment |
| `delete` | `rm`, `remove` | Delete an environment |
| `edit` | `update` | Edit an environment's configuration |
| `config` | `show`, `info` | Show environment configuration |

## Examples

### Link an environment (interactive)

```bash
railway environment
```

### Link a specific environment

```bash
railway environment staging
```

### Create a new environment

```bash
railway environment new staging
```

### Duplicate an environment

```bash
railway environment new staging --duplicate production
```

Or using the alias:

```bash
railway environment new staging --copy production
```

### Delete an environment

```bash
railway environment delete staging
```

### Edit environment configuration

```bash
railway environment edit --service-config backend variables.API_KEY.value "secret"
```

### Show environment configuration

```bash
railway environment config
```

## Options for `new`

| Flag | Description |
|------|-------------|
| `-d, --duplicate <ENV>` | Environment to duplicate (alias: `--copy`) |
| `--json` | Output in JSON format |

## Options for `delete`

| Flag | Description |
|------|-------------|
| `-y, --yes` | Skip confirmation dialog |
| `--2fa-code <CODE>` | 2FA code for verification |
| `--json` | Output in JSON format |

## Options for `edit`

| Flag | Description |
|------|-------------|
| `-e, --environment <ENV>` | Environment to edit |
| `-s, --service-config <SERVICE> <PATH> <VALUE>` | Configure a service using dot-path notation |
| `-m, --message <MSG>` | Commit message for the changes |
| `--stage` | Stage changes without committing |
| `--json` | Output in JSON format |

### Dot-path notation for `--service-config`

The `--service-config` flag uses dot-path notation to specify nested configuration values:

```bash
# Set a variable value
railway environment edit --service-config backend variables.API_KEY.value "secret"

# Set a build command
railway environment edit --service-config api build.buildCommand "npm run build"

# Set a monorepo root directory
railway environment edit --service-config api source.rootDirectory /packages/api
```

The format is: `--service-config <SERVICE_NAME> <DOT.PATH.TO.PROPERTY> <VALUE>`

For more information about configuring monorepo services, see [Deploying a monorepo](/deployments/monorepo).

## Options for `config`

| Flag | Description |
|------|-------------|
| `-e, --environment <ENV>` | Environment to show configuration for (defaults to linked environment) |
| `--json` | Output in JSON format |

### Config examples

Show configuration for the current environment:

```bash
railway environment config
```

Show configuration for a specific environment:

```bash
railway environment config --environment staging
```

Output as JSON:

```bash
railway environment config --json
```

## Related

- [railway link](/cli/link)
- [Environments](/environments)
