---
title: railway variable
description: Manage environment variables.
---

Manage environment variables for a service.

## Usage

```bash
railway variable [COMMAND] [OPTIONS]
```

## Aliases

- `railway variables`
- `railway vars`
- `railway var`

## Subcommands

| Subcommand | Aliases | Description |
|------------|---------|-------------|
| `list` | `ls` | List variables for a service |
| `set` | | Set a variable |
| `delete` | `rm`, `remove` | Delete a variable |

## Examples

### List variables

```bash
railway variable list
```

### List in key-value format

```bash
railway variable list --kv
```

Output:
```
DATABASE_URL=postgres://...
API_KEY=secret123
```

### Set a variable

```bash
railway variable set API_KEY=secret123
```

### Set multiple variables

```bash
railway variable set API_KEY=secret123 DEBUG=true
```

### Set an empty value

Use an empty assignment to set a variable to the empty string:

```bash
railway variable set OPTIONAL_TOKEN=
```

This keeps `OPTIONAL_TOKEN` defined. Use `railway variable delete` when you
want to remove the variable instead.

### Set variable from stdin

```bash
echo "my-secret-value" | railway variable set SECRET_KEY --stdin
```

### Delete a variable

```bash
railway variable delete API_KEY
```

## Options for `list`

| Flag | Description |
|------|-------------|
| `-s, --service <SERVICE>` | Service to list variables for |
| `-e, --environment <ENV>` | Environment to list variables from |
| `-k, --kv` | Show variables in KEY=VALUE format |
| `--json` | Output in JSON format |

## Options for `set`

| Flag | Description |
|------|-------------|
| `-s, --service <SERVICE>` | Service to set the variable for |
| `-e, --environment <ENV>` | Environment to set the variable in |
| `--stdin` | Read value from stdin (use with single KEY) |
| `--skip-deploys` | Skip triggering deploys |
| `--json` | Output in JSON format |

Successful non-interactive `set` commands print the keys that were updated,
even when a terminal spinner isn't available.

## Options for `delete`

| Flag | Description |
|------|-------------|
| `-s, --service <SERVICE>` | Service to delete the variable from |
| `-e, --environment <ENV>` | Environment to delete the variable from |
| `--json` | Output in JSON format |

## Legacy flags

The following flags are deprecated but still supported:

```bash
# Deprecated: use 'Railway variable set KEY=VALUE' instead
railway variable --set KEY=VALUE

# Deprecated: use 'Railway variable set key --stdin' instead
railway variable --set-from-stdin KEY
```

## Related

- [Variables](/variables)
- [railway run](/cli/run)
