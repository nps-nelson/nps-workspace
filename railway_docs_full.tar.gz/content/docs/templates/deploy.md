---
title: Deploy a Template
description: Learn how to deploy Railway templates.
---

Templates allow you to deploy a fully configured project that is automatically
connected to infrastructure.

You can find featured templates on the <a href="https://railway.com/templates" target="_blank">template marketplace</a>.

## Template deployment flow

To deploy a template -

- Find a template from the marketplace and click `Deploy Now`
- If necessary, configure the required variables, and click `Deploy`
- Upon deploy, you will be taken to your new project containing the template service(s)
  - Services are deployed directly from the defined source in the template configuration
  - After deploy, you can find the service source by going to the service's settings tab
  - Should you need to make changes to the source code, you will need to [eject from the template repo](#eject-from-template-repository) to create your own copy. See next section for more detail.

_Note: You can also deploy templates into existing projects, by clicking `+ New` from your project canvas and selecting `Template`._

## Getting help with a template

If you need help with a template you have deployed, you can ask the template creator directly:

1. Find the template page in the [marketplace](https://railway.com/templates)
2. Click **"Discuss this Template"** on the template details page
3. Your question will be posted to the template's queue where the creator can help

Template creators are notified when questions are posted and are incentivized to provide helpful responses through Railway's kickback program.

<Image src="https://res.cloudinary.com/railway/image/upload/v1764639364/Ask_the_Template_Creator_wwzlca.png" alt = "Ask the Template Creator" width={1538} height={1618} quality={100} />

## Eject from template repository

<Banner variant="info">
As of March 2024, the default behavior for deploying templates, is to attach to and deploy directly from the template repository.  Therefore, you will not automatically get a copy of the repository on deploy.  Follow the steps below to create a repository for yourself.
</Banner>

By default, services deployed from a template are attached to and deployed directly from the template repository. In some cases, you may want to have your own copy of the template repository.

Follow these steps to eject from the template repository and create a mirror in your own GitHub account.

1. In the [service settings](/overview/the-basics#service-settings), under Source, find the **Upstream Repo** setting
2. Click the `Eject` button
3. Select the appropriate GitHub organization to create the new repository
4. Click `Eject service`

## Updatable templates

When you deploy any services from a template based on a GitHub repo, every time you visit the project in Railway, we will check to see if the project it is based on has been updated by its creator.

If it has received an upstream update, we will create a branch on the GitHub repo that was created when deploying the template, allowing for you to test it out within a PR deploy.

If you are happy with the changes, you can merge the pull request, and we will automatically deploy it to your production environment.

If you're curious, you can read more about how we built updatable templates in this <a href="https://blog.railway.com/p/updatable-starters" target="_blank">blog post</a>

_Note: This feature only works for services based on GitHub repositories. At this time, we do not have a mechanism to check for updates to Docker images from which services may be sourced._

