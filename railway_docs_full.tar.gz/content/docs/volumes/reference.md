---
title: Volumes
description: Volumes are a feature that enables persistent data for services on Railway.
---

Volumes are a feature that enables persistent data for [services](/services) on Railway.

## How it works

When mounting a volume to a service, a volume is made available to the service on the specified mount path.

## Size limits

Volumes have a default size based on the [subscription plan](/pricing/plans#plans).

- Free and Trial plans: **0.5GB**
- Hobby plans: **5GB**
- Pro plan: **50GB**

Volumes can be resized on all paid plans (Hobby and Pro), including via live resize with zero downtime.

Pro users and above can self-serve to increase their volume up to 1 TB.

For storage needs beyond 1TB, an [Enterprise plan](/pricing/plans) is required. Enterprise users with $2,000/month committed spend can also use [Slack](/platform/support#slack).

## Volume limits per project

Each project has a maximum number of volumes that can be created, based on your subscription plan:

| Plan | Maximum Volumes per Project |
|------|----------------------------|
| **Free** | **1** |
| **Trial** | **3** |
| **Hobby** | **10** |
| **Pro** | **20, can be increased** |
| **Enterprise** | **Unlimited** |

Volumes created for the same service in another environment do not count towards this limit.

Pro users with substantial usage requirements may be eligible for increased volume limits. Please reach out to us on the [Railway Help Station](https://station.railway.com/questions) to discuss your project's needs.

## I/O specifications

Volumes have the following I/O characteristics:

- **Read IOPS**: 3,000 operations per second
- **Write IOPS**: 3,000 operations per second

These specifications apply to all volume sizes and subscription plans.

## Pricing

Volumes are billed at a rate per GB / minutely, and invoiced monthly. You can find [specific per-minute pricing here](/pricing/plans#resource-usage-pricing).

You are only charged for the amount of storage used by your volumes. _Each volume requires approx 2-3% of the total storage to store metadata about the filesystem, so a new volume will always start with some used amount of space used depending on the size._

## Backups

Services with volumes support manual and automated backups, backups are covered in the [backups](/volumes/backups) reference guide.

## Deletion and Restoration

When a volume is deleted, it is queued for deletion and will be permanently deleted within 48 hours. You can restore the volume during this period using the restoration link sent via email.

After 48 hours, deletion becomes permanent and the volume cannot be restored.

## Caveats

Here are some limitations of which we are currently aware:

- Each service can only have a single volume
- Replicas cannot be used with volumes
- To prevent data corruption, we prevent multiple deployments from being active
  and mounted to the same service. This means that there will be a small amount
  of downtime when re-deploying a service that has a volume attached, even if there is a healthcheck endpoint configured
- Down-sizing a volume is not currently supported, but increasing size is supported
- Volume resizing is performed live without downtime. The underlying storage is expanded while your service continues running, and the filesystem automatically extends to utilize the additional space. In certain scenarios, such as when a volume reaches 100% capacity, an offline resize is automatically performed instead to run data integrity checks, which will restart your service
- Volume files can be managed from the CLI with `railway volume browse` or `railway volume files`, and over `sftp` or `scp` through a service the volume is attached to (see [railway ssh](/cli/ssh))
- Docker images that run as a non-root UID by default will have permissions issues when performing operations within an attached volume. If you are affected by this, you can set `RAILWAY_RUN_UID=0` environment variable in your service.

## Support

Refer to the guide on [how to use volumes](/volumes) for more details on how to use the feature.
