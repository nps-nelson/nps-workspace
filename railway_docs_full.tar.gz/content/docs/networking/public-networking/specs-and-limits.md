---
title: Specs & Limits
description: Technical specifications and rate limits for Railway's public networking.
---

_This information is subject to change at any time._

## Technical specifications

| Category                 | Key Information                                                                                                                                                                                                                                                                                                                                                                                                                                |
| ------------------------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| **DNS/Domain Names**     | - Support for domains, subdomains, and wildcard domains.<br/>- Subdomains and wildcards cannot overlap (`foo.hello.com` cannot exist with `*.hello.com` unless owned by the same service).<br/>- Root domains need a DNS provider with ALIAS records or CNAME flattening.<br/>- Unicode domains should be PUNYcode encoded.<br/>- Non-public/internal domain names are not supported.                                                          |
| **Certificate Issuance** | - Railway attempts to issue a certificate for **up to 72 hours** after domain creation before failing.<br/>- Certificates are expected to be issued within an hour.                                                                                                                                                                                                                                                                            |
| **TLS**                  | - Support for TLS 1.2 and TLS 1.3 with specific cipher sets.<br/>- Certificates are valid for 90 days and renewed when 30 days of validity remain.                                                                                                                                                                                                                                                                                                               |
| **Edge Traffic**         | - Support for HTTP/1.1 and HTTP/2.<br/>- Support for websockets over HTTP/1.1.<br/>- Idle HTTP/1.1 connections are closed after 60 seconds between requests. This does not apply to HTTP/2 or websocket connections.<br/>- Max 32 KB combined header size.<br/>- HTTP requests can run for up to 15 minutes if data keeps transferring (for example, keep-alive heartbeats), and are otherwise closed after 5 minutes with no data transferred.<br/>- Request bodies must finish uploading within 5 minutes.<br/>- Websocket connections are exempt from these duration and inactivity limits, and can stay open indefinitely, even while idle.                                                                                                                                                                                                                          |
| **Request Headers**      | - `X-Real-IP` for identifying client's remote IP.<br/>- `X-Forwarded-Proto` always indicates `https`.<br/>- `X-Forwarded-Host` for identifying the original host header.<br/>- `X-Railway-Edge` for identifying the edge [POP](https://status.railway.com/locations) that handled the request.<br/>- `X-Request-Start` for identifying the time the request was received (Unix milliseconds timestamp).<br/>- `X-Railway-Request-Id` for correlating requests against network logs.<br/>- `X-Railway-Debug` can be sent by clients with any value to receive extra debug response headers, currently `X-Railway-Upstream-Zone` (the origin zone that served the request). |
| **Requests**             | - Inbound traffic must be TLS-encrypted<br/>- HTTP GET requests to port 80 are redirected to HTTPS.<br/>- HTTP POST requests to port 80 are redirected to HTTPS as GET requests.<br/>- SNI is required for correct certificate matching.                                                                                                                                                                                                       |

## Rate limits

To ensure the integrity and performance of the Railway network, we enforce the following limits for all services.

| Category                    | Limit                         | Description                                               |
| --------------------------- | ----------------------------- | --------------------------------------------------------- |
| **Maximum Connections**     | 10,000 concurrent connections | The number of concurrent connections.                     |
| **HTTP Requests/Sec**       | 11,000~ RPS                   | The number of HTTP requests to a given domain per second. |
| **Requests Per Connection** | 10,000 requests               | The number of requests each connection can make.          |

If your application requires higher limits, please don't hesitate to reach out to us at [team@railway.com](mailto:team@railway.com).

## Traffic types

We support HTTP/1.1 and HTTP/2 traffic from the internet to your services.

All traffic must be HTTPS and use TLS 1.2 or above, and TLS SNI is mandatory for requests.

- Plain HTTP GET requests will be redirected to HTTPS with a `301` response.
- Plain HTTP POST requests will be converted to GET requests.

For services that require TCP traffic, like databases, we also have [TCP Proxy](/networking/tcp-proxy) support.

## SSL certificates

We provide Let's Encrypt SSL certificates using ECDSA keys. Certificates are valid for 90 days and are automatically renewed 2 months into their life.

Certificate issuance should happen within an hour of your DNS being updated with the values we provide.

For proxied domains (Cloudflare orange cloud), we may not always be able to issue a certificate for the domain, but Cloudflare to Railway traffic will be encrypted with TLS using the default Railway `*.up.railway.app` certificate.

## DDoS protection

Railway Metal infrastructure is built to mitigate attacks at network layer 4 and below. While we do have limits in place to protect your applications from layer 7 attacks, they may not always be enough to stop your application from becoming overwhelmed. In this case, please refer to [WAF](/networking/waf) for details on how to enable **Under Attack Mode**.