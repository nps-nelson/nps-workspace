---
title: Compliance
description: Learn about Railway's compliance standards and how we ensure security and regulatory adherence.
---

Railway is designed to be used by companies of all sizes. We understand that companies have different needs when it comes to compliance and security. We are happy to work with you to ensure that Railway meets your needs. We work with teams across regulated industries such as government, healthcare, and finance to ensure that Railway meets their needs.

Companies choose Railway so that they can speed up their development velocity while also maintaining their security and compliance posture.

We are happy to sign NDAs with your company to provide additional information about Railway's security and compliance practices. Please reach out to us at [team@railway.com](mailto:team@railway.com) to get started, or click [here](https://cal.com/team/railway/work-with-railway?duration=30) to book some time to chat.

You can request to view Railway's audit, compliance, security, and regulatory documents and processes on the [Trust Center at trust.railway.com](https://trust.railway.com).

Additionally, the Railway enterprise plan is the most secure and compliant option. [Read about the Railway enterprise plan here](https://railway.com/enterprise).

## Certifications

We know that your businesses need to develop strong and lasting relationships with your vendors to build confidence that we can be trusted to deliver your workloads. Part of that is through certifications, audits, and continual refinement of Railway's practices. Railway aims to comply with all the distributions of workloads and privacy procedures.

### SOC 2 type ii and SOC 3

Railway is SOC 2 Type II certified and SOC 3 certified.

Customers who are in the process of securing SOC 2 certification can request a copy of the Railway security audit on the [Trust Center](https://trust.railway.com).

### HIPAA BAA

Railway follows a shared responsibility model for HIPAA compliance and PHI. Railway will make its best effort to advise your company on setting up encryption for your data, auditing the storage of keys, establishing access control, and ensuring secure storage of sensitive patient data. When a BAA is in effect, the Railway team will no longer be able to directly access your running workloads.

HIPAA BAA is an add-on with a paid monthly spend threshold. All pricing goes towards your [usage on Railway](/pricing/plans#committed-spend-tiers). Monthly thresholds for addons is found in the [committed spend pricing](/pricing/plans#committed-spend-tiers).

If your company needs a BAA, you can contact the Railway solutions team at [team@railway.com](mailto:team@railway.com), or click [here](https://cal.com/team/railway/work-with-railway?duration=30) to schedule some time to chat.

## Privacy

Railway is committed to protecting the privacy of Railway's users. We understand that when working with user code and data, it is important to have a clear understanding of how we handle your data. Railway, on behalf of Railway's users, may remove offending workloads but at no point will a Railway team member modify your application without your expressed permission through an approved communication channel.

[Click here to see Railway's Privacy Policy.](https://railway.com/legal/privacy)

## GDPR compliance - data processing agreement (DPA)

Railway provides a Data Processing Agreement (DPA) to help customers comply with GDPR requirements when processing personal data through the Railway platform. If you operate a business in the EU or process personal data of EU residents, you may need to execute a DPA with Railway to ensure compliance with GDPR Article 28 requirements for data processor relationships.

You can access and execute Railway's standard DPA through the self-service link: [Sign Railway's DPA](https://powerforms.docusign.net/0c38a448-eda3-4139-99d6-f9c0eef94154?env=na4&acct=c0c04fce-9579-4f79-b028-7a946a40077d&accountId=c0c04fce-9579-4f79-b028-7a946a40077d)

You can also review Railway's standard DPA terms at [railway.com/legal/dpa](https://railway.com/legal/dpa).

## VAT tax ID and address

Customers in the EU may need to add their VAT Tax ID to their invoices for compliance and reporting purposes.

You can add your VAT Tax ID and address on Railway in your [Workspace settings](https://railway.com/workspace/billing) -> Billing -> Manage Subscription.

If you have multiple workspaces, you need to add your VAT Tax information to each respective Workspace's Subscription.

After adding your information, it will appear on your future invoices.

## EU DORA

For European organizations in finance that need to comply with [EU Dora](https://www.eiopa.europa.eu/digital-operational-resilience-act-dora_en) - Railway is willing to provide documents after a click through NDA that describe disaster recovery procedures, uptime statistics, and IT controls for organizations to who need to submit compliance documents to local regulators. You can get information on the [Trust Page](https://trust.railway.com)

## Deploy securely on Railway

If compliance is top of mind, the Railway enterprise plan will meet your needs. From product features like SSO, to higher capacity limits, to security audits, the Railway enterprise plan is made to satisfy even the largest organizations. [Read more about the Railway enterprise plan](https://railway.com/enterprise).
