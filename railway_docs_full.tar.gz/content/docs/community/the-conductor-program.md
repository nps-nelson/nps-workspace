---
title: The Conductor Program
description: Learn about Railway’s Conductor Program and how it empowers the developer community.
---

The Conductor Program brings together the amazing people who make Railway's community special. Conductors shepherd the experience for Railway's 45K+ community members. They are the bridge between the Railway team and the thriving Railway community.

This program aims to foster collaboration and help Railway's Conductors grow.

## What do conductors do?

Railway's Conductors spend time on Central Station answering questions, sharing tips, and making sure everyone can use Railway successfully.

Here are a few key ways they contribute -

- Providing community support on [Central Station](https://station.railway.com/).

- Maintaining a healthy and welcoming community atmosphere while moderating the Railway channels and templates.

- Contributing to Railway's open-source projects through improvements and new features.

- Creating a direct feedback loop between users and the Railway team.

Through these activities, Conductors ensure everyone can use Railway successfully while helping to build a collaborative and supportive community environment.

## Ready to become a conductor?

Are you passionate about helping others and love being part of Railway's community? We're always excited to welcome new Conductors who share Railway's enthusiasm for community engagement!

Here's what we look for in potential Conductors -

- Have demonstrated experience with Railway's platform and services.

- Show a consistent track record of helping others in the Railway community.

- Maintain professional and friendly communication.

- Are active participants on Central Station.

- Demonstrate strong technical problem-solving abilities.

The ideal Conductor combines technical expertise with mentorship skills to help the Railway community thrive!

<TallyButton data-tally-open="nP2qqd" data-tally-width="700" data-tally-emoji-text="👋" data-tally-emoji-animation="wave" data-tally-auto-close="2000">Apply Now</TallyButton>

## Conductor benefits

Being a Conductor comes with several exciting perks and rewards to recognize your valuable contributions to the community.

As part of the program, conductors will receive -

- 100% off discount for the Pro plan's subscription and resource costs.

- A Claude Max 20x subscription, covered by Railway.

- Cash payouts for solving complex issues for users.

- The opportunity to earn payouts for OSS contributions ([CLI](https://github.com/railwayapp/cli), [Railpack](https://github.com/railwayapp/railpack), [Docs](https://github.com/railwayapp/docs), etc).

- First access to [template bounties](https://github.com/railwayapp/templates/wiki/Template-Bounties).

- Letters of recommendation for educational institutions and employer references.

- Moderation status on [Central Station](https://station.railway.com/).

- Access to a team workspace shared with other Conductors.

- A direct line to the team via the private Conductor only channel.

- Your choice of [Railway Swag](https://shop.railway.com/).

And to top it all off, each quarter we reward the most outstanding conductor with a pizza party! 🎉

## Conductor participation

We believe in fostering an active and supportive Conductor program that enables everyone to make meaningful contributions. To help keep the Railway community vibrant, we conduct friendly quarterly check-ins with all Conductors.

As a Conductor, you'll contribute regularly in these key areas -

- Community Engagement

  - Being an active, welcoming presence in community channels.

  - Building connections with fellow community members.

  - Joining community conversations and sharing experiences.

  - Looking out for the community by making sure discussions stay positive and helpful.

- Support Activities

  - Helping others on [Central Station](https://station.railway.com/).

  - Showing consistent engagement by regularly contributing to meaningful solutions across all Railway platforms.

- Open Source Contributions

  - Contributing through either small improvements or substantial feature additions.

  - New features should address community-requested needs with demonstrated user demand.

  - Bug fixes should focus on issues affecting multiple users.

We understand that maintaining consistent participation across these areas requires dedication and time. As part of Railway's commitment to supporting Conductors, we have quarterly check-ins to discuss your experience and ensure you have everything needed to succeed.

While we aim for regular engagement, we recognize that life circumstances and priorities can change. If participation becomes limited, we may need to transition members out of the program during the bi-annual review. However, the door always remains open – former Conductors are welcome to rejoin the program when their schedule better accommodates regular participation!
