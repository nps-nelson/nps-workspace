---
title: MySQL
description: Learn how to deploy a MySQL database on Railway.
---

The Railway MySQL database template allows you to provision and connect to a MySQL database with zero configuration.

### Deploy

Add a MySQL database to your project via the `ctrl / cmd + k` menu or by clicking the `+ New` button on the Project Canvas.

<Image src="https://res.cloudinary.com/railway/image/upload/v1695934218/docs/databases/addDB_qxyctn.gif"
alt="GIF of the Adding Database"
layout="responsive"
width={450} height={396} quality={100} />

You can also deploy it via the [template](https://railway.com/deploy/mysql) from the template marketplace.

#### Deployed service

Upon deployment, you will have a MySQL service running in your project, deployed directly from the [mysql Docker image](https://hub.docker.com/_/mysql).

### Connect

Connect to MySQL from another service in your project by [referencing the environment variables](/variables#referencing-another-services-variable) made available in the MySQL service:

- `MYSQLHOST`
- `MYSQLPORT`
- `MYSQLUSER`
- `MYSQLPASSWORD`
- `MYSQLDATABASE`
- `MYSQL_URL`

#### Connecting externally

It is possible to connect to MySQL externally (from outside of the [project](/projects) in which it is deployed). Databases are deployed private by default — to expose one, open the service's **Settings → Networking** and add **Public Access**. This creates a [TCP Proxy](/networking/tcp-proxy) and populates a `MYSQL_PUBLIC_URL` variable with the external connection string.

_Keep in mind that you will be billed for [Network Egress](/pricing/plans#resource-usage-pricing) when using the TCP Proxy._

### Modify the deployment

Since the deployed container is pulled from the official MySQL image in Docker hub, you can modify the deployment based on the [instructions in Docker hub](https://hub.docker.com/_/mysql).

## High availability

An existing MySQL service can be converted into a high-availability cluster with automatic failover, backed by Group Replication and HAProxy. See [Upgrading MySQL to High Availability](/databases/mysql-ha) for the full guide.

## Backups and observability

Especially for production environments, performing regular backups and monitoring the health of your database is essential. Consider adding:

- **Backups**: Automate regular backups to ensure data recovery in case of failure. We suggest checking out the native [Backups](/volumes/backups) feature.

- **Point-in-time recovery**: Restore to any moment in the last 7 days, not just to a backup, by turning on continuous binlog archiving from the **Backups** tab. Works on single-node MySQL and on MySQL HA clusters. See [Point-in-Time Recovery](/volumes/point-in-time-recovery).

- **Observability**: Implement monitoring for insights into performance and health of your databases. If you're not already running an observability stack, check out these templates to help you get started building one:
  - [Prometheus](https://railway.com/deploy/KmJatA)
  - [Grafana](https://railway.com/deploy/anURAt)

## Additional resources

Railway maintains this template; [what Railway manages](/databases#what-railway-manages) lists which operations Railway handles and which are yours. Changing the template as shipped, such as its image, start command or variables, makes the database yours to manage; see [database support scope](/databases#database-support-scope).

We _strongly encourage you_ to refer to the source documentation to gain deeper understanding of their functionality and how to use them effectively. Here are some links to help you get started:

- [MySQL Documentation](https://dev.mysql.com/doc/relnotes/mysql/8.4/en/)
- [MySQL InnoDB Cluster Documentation](https://dev.mysql.com/doc/mysql-shell/8.0/en/mysql-innodb-cluster.html)
- [MySQL Router Documentation](https://dev.mysql.com/doc/mysql-router/8.0/en/mysql-router-general.html)
