---
title: Committed Spend Tiers
description: Learn about Railway's committed spend tier system.
---

Railway offers committed spend tiers for customers with consistent usage needs. Instead of negotiated contract pricing, customers can commit to a specific monthly spend level to unlock additional features and services.

## Available tiers

| Committed spend tier | Features                                                                             |
| -------------------- | ------------------------------------------------------------------------------------ |
| $1000                | 90-day log history, HIPAA BAAs                                                       |
| $2000                | Single Sign-On, Role-based access control, 18 month Audit Logs retention             |
| $5000                | Slack Connect channels, Critical level support tickets, Enterprise Resource Limits, Railway Authentication |
| $10000               | Dedicated instances                                                                  |

## How to subscribe

These tiers can only be accessed from a workspace on the Pro plan. To access a committed spend tier:

1. Upgrade your workspace to the [Pro plan](/pricing/plans) if you haven't already.
2. Navigate to your workspace Settings -> Plans page.
3. Scroll down to see Committed Spend and Enterprise tier options.

<Image src="https://res.cloudinary.com/railway/image/upload/v1772655571/docs/committed_spend_from_pro_qfa6uc.png"
alt="Committed spend on the pro plan"
layout="intrinsic"
width={800} height={468} quality={100} />

## Feature definitions

### 90-day log history
Extended log retention for better historical analysis and auditing.

### HIPAA BAAs
HIPAA Business Associate Agreements for compliant health data handling. Requires a year commitment paid monthly.

### Single sign-on
Allow workspace members to sign in using your organization’s Identity Provider (IdP), including Okta, Auth0, Microsoft Entra ID, Google Workspace, and more.

### Role-based access control
Restrict access to sensitive environments like production. Only workspace admins can access restricted environments.

### 18 month audit logs retention
Extended log retention for better historical analysis and auditing.

### Enterprise Resource Limits
Higher per-replica resource limits at 48 vCPU / 48 GB RAM / 50 replicas per service. Up to 2,400 vCPU / 2,4 TB RAM per service.

### Slack Connect channels
A private channel with the solutions team at Railway on Slack to facilitate better communication and support.

### Critical level support tickets
Critical tickets allow you to page our support on-call directly for an immediate response.

### Railway Authentication
An identity-aware proxy that requires visitors to sign in with Railway and be a member of the project before they can reach a service over HTTP. Workspace admins can turn it on for a whole environment or for individual services. See [Railway Authentication](/enterprise/guardrails#railway-authentication).

### Dedicated instances
Custom dedicated infrastructure for enhanced performance and control.


## FAQs

### What happens if my usage is less than the committed spend tier I am subscribed to?

We will add a line item to your invoice to make up for the difference and you will be billed the price of the committed spend tier you are on.
For example: If you're subscribed to the $2000 tier and your usage is $1400, we will add a $600 line item making your bill $2000.

### How do I cancel my committed spend tier subscription?

You can cancel your commitment by going to your workspace billing page. Note: You will immediately lose access to the features attached to the tier upon cancelation.

### My question isn't answered here, where can I speak to the team?
To learn more about committed spend tiers, please [contact our team](mailto:team@railway.com?subject=Business%20Class%20Support).
