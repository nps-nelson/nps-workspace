---
title: AWS Marketplace
description: Learn about Railway's AWS Marketplace offering and pricing.
---

Railway is available through the AWS Marketplace, allowing you to purchase and manage Railway through your AWS account.

## Offering

For large Enterprises, Railway can be an option for large engineering teams to significantly reduce operational overhead.

## Pricing structure

Pricing for Railway through AWS Marketplace is based on contract duration. You can pay upfront or in installments according to your contract terms with the vendor. The contract includes:

- A specified quantity of usage for the contract duration
- Usage-based pricing for any usage exceeding the entitled amount
- Additional charges applied on top of the contract price for overages

## Contract terms

### 12-month contract

The standard offering is a 12-month contract with the following terms:

- Base price: $10,000.00 per 12 months
- Overage rate: $1.00 per unit
- Private pricing agreements available through the Railway sales team

## Refund policy

All fees are non-refundable and non-cancellable except as required by law.

## Getting started

To purchase Railway through AWS Marketplace:

1. Visit the Railway listing on AWS Marketplace
2. Click "View purchase options"
3. Contact the Railway sales team
4. Complete the purchase through your AWS account

## Support

For questions about AWS Marketplace purchases or to discuss private pricing agreements, [please contact the Railway sales team.](https://cal.com/team/railway/work-with-railway)
