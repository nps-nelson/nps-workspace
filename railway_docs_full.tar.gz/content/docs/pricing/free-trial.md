---
title: Free Trial
description: Learn about Railway's free trial plan.
---

New users can take the platform for a spin by starting a free trial. The trial gives access to basic features for up to 30 days and includes a one-time grant of $5.

After 30 days passes or $5 is spent, the free trial reverts to the [Free](/pricing/plans#plans) plan, which provides $1 of free credit per month. The credit does not roll over month to month.

## Try without an account

You can try Railway before signing up. Run `ssh railway.new` to get a free Linux VM with coding agents preinstalled and a preview URL, with no account or credit card. Railway identifies you by your SSH key.

| Limit        | Value                        |
| ------------ | ---------------------------- |
| VM size      | 2 vCPU, 2 GB RAM             |
| Build time   | 60 minutes                   |
| Claim window | 24 hours                     |
| Boxes        | 3 per IP address per day     |

Compute for an unclaimed box is free. To keep it, open the claim link from the welcome message and sign up; the box moves into your account with the same VM, files, and URL. Unclaimed boxes are deleted with their files. See [railway.com/free-vm](https://railway.com/free-vm) for more.

When demand is high, Railway caps how many free VMs run at once in each region. If you hit the cap, you'll see "Anonymous trials are temporarily disabled. Try again shortly, or sign up to keep building." That attempt doesn't count against your daily limit.

## Full VS limited trial

Your trial experience depends on whether Railway can verify your account.

| Trial Type        | Deploy Code | Deploy Databases | Deploy Buckets | Network Access |
| ----------------- | ----------- | ---------------- | -------------- | -------------- |
| **Full Trial**    | ✅          | ✅               | ✅             | Full           |
| **Limited Trial** | ✅          | ✅               | ✅             | Restricted     |

When you sign up for a free Trial, you can connect your GitHub account to initiate verification. Your verification status depends on a number of factors, including the age and activity of your GitHub account.

If your account is not verified (either because you have not initiated the verification process or your account does not meet Railway's criteria for verification), your trial will have some network restrictions. Specifically, services on the Limited Trial have restricted outbound network access and only a limited set of ports are available.

Verification is a necessary measure to prevent abuse of the free Trial, limiting users from creating multiple accounts and reducing the risk of trial users deploying or hosting content that violates Railway's [Terms of Service](https://railway.com/legal/fair-use).

This is a fully automated process, and Railway does not respond to requests for verification. If your account is not verified, you can upgrade to the Hobby plan to unlock the full Railway experience.

## FAQs

### How do I get started with the free trial?

If you do not already have a Railway account, you can sign up for a free Trial by clicking "Login" at [railway.com](https://railway.com/).

### How does the trial work?

When you sign up for the free Trial, you will receive a one-time grant of $5 in credits that you can use to try out Railway. The credits will be applied towards any usage on the platform and expire in 30 days.

If you upgrade to a plan while you still have a credit balance from the Trial, the remaining balance will carry over to your new plan. To prevent fraud and ensure your payment method is valid and in good standing, the carried-over Trial credits may not be applied to your first billing cycle, and will instead be applied as a discount to subsequent charges once a successful payment has been processed.

### What resources can I access during the trial?

During the trial, you can access the same features as on the Hobby plan, however you will be limited to 1 GB of RAM and shared (rather than dedicated) vCPU cores. Additionally, your projects will be limited to 5 services per project.

As a trial user, you can spin up databases and deploy code. However, if you are on the [Limited Trial](#full-vs-limited-trial), your services will have some network restrictions.

### What's the difference between the limited trial and the full trial?

If you connect your GitHub account, and we are able to verify it against a set of parameters, you will be on the Full Trial with full network access.

If you do not connect a GitHub account, or we are not able to verify your account, you will be on the Limited Trial. You can still deploy code, databases, and buckets, but your services will have restricted outbound network access and only a limited set of ports will be available.

While you're on the Limited Trial, you can initiate verification at any time by visiting [railway.com/verify](https://railway.com/verify) in order to access the Full Trial experience.

### How far will the $5 one-time trial grant last?

The longevity of your one-time trial grant depends on how many resources you consume within the 30 day period you sign-up for the platform. The more resources you deploy, the greater the consumption.

### Data retention

Railway deletes stateful volumes created by Trial accounts 30 days after the expiration of your credits. To retain your data, upgrade your account after the Trial period.
