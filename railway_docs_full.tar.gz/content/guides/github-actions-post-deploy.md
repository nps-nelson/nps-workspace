---
title: GitHub Actions Post-Deploy
description: Learn how to use GitHub Actions to run post-deployment commands.
date: "2026-01-30"
tags:
  - github-actions
  - ci-cd
  - automation
topic: architecture
---

[GitHub Actions](https://github.com/features/actions) come with a pretty neat set of features to automate your workflows. This post talks about using GitHub Actions to run post-deploy actions.

At Railway, we've set up GitHub triggers for automatic deployments when you push to a selected branch, and with GitHub Actions, you can automate several parts of your development workflow. Recently, within the Railway [Discord](https://discord.gg/railway) and [Slack](/platform/support#slack), we've had a couple of users ask us how they'd go about running commands or webhooks after their app is deployed so we thought it'd be a good idea to publish a short tutorial doing just that, with GitHub Actions.

## The action

Since Railway makes the deployment status available to GitHub, you'll be using the `deployment_status` event to trigger your action. This event is triggered when a deployment status changes, and you'll be using the `success` state to trigger your action.

Make a new file in your repository called `.github/workflows/post-deploy.yml` and add the following -

```yaml
name: Post-Deployment Actions

on:
  deployment_status:
    states: [success]

jobs:
  post-deploy:
    runs-on: ubuntu-latest
    if: github.event.deployment_status.state == 'success'
    steps:
      - name: Debug - Print github.event object
        run: |
          echo "github.event context:"
          echo '${{ toJSON(github.event) }}'

      # Only run if this is a production environment deployment that succeeded
      - name: Run post-deploy actions
        if: github.event.deployment.environment == 'production'
        run: |
          echo "Production deployment succeeded"
```

Check out the contents of `github.event` to build your own conditions.

It's that simple! You can now customize the final run step to execute any commands or send webhooks using Curl or other methods of your choice.

## Conclusion

We hope this tutorial has been helpful and that you'll find it useful for your own projects. If you have any questions or feedback, please feel free to reach out to us on [Slack](/platform/support#slack) or [Central Station](https://station.railway.com). Happy coding!
