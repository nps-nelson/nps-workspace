const redirects = [
  {
    source: "/cloud-agents/opencode2",
    destination: "/cloud-agents/opencode",
    permanent: true,
  },
  {
    source: "/cloud-agents/opencode/beta",
    destination: "/cloud-agents/opencode",
    permanent: true,
  },
  {
    source: "/api/llms-docs.md",
    destination: "/llms-full.txt",
    permanent: true,
  },
  {
    source: "/troubleshooting/slow-deployments",
    destination: "/deployments/troubleshooting/slow-deployments",
    permanent: true,
  },
  {
    source: "/troubleshooting/nodejs-sigterm",
    destination: "/deployments/troubleshooting/nodejs-sigterm-handling",
    permanent: true,
  },
  {
    source: "/deployments/troubleshooting/nodejs-sigterm",
    destination: "/deployments/troubleshooting/nodejs-sigterm-handling",
    permanent: true,
  },
  {
    source: "/troubleshooting/no-start-command-could-be-found",
    destination: "/deployments/troubleshooting/no-start-command-could-be-found",
    permanent: true,
  },
  {
    source: "/access/multi-factor-auth",
    destination: "/access/multi-factor-authentication",
    permanent: true,
  },
  // Builds troubleshooting
  {
    source: "/troubleshooting/nixpacks-was-unable-to-generate-a-build-plan",
    destination: "/builds/railpack",
    permanent: true,
  },
  // Networking troubleshooting
  {
    source: "/troubleshooting/application-failed-to-respond",
    destination: "/networking/troubleshooting/application-failed-to-respond",
    permanent: true,
  },
  {
    source: "/troubleshooting/405-method-not-allowed",
    destination: "/networking/troubleshooting/405-method-not-allowed",
    permanent: true,
  },
  // Databases troubleshooting
  {
    source: "/troubleshooting/enotfound-redis-railway-internal",
    destination: "/databases/troubleshooting/enotfound-redis-railway-internal",
    permanent: true,
  },
  // Existing networking file relocations
  {
    source: "/networking/troubleshooting-ssl",
    destination: "/networking/troubleshooting/ssl",
    permanent: true,
  },
  {
    source: "/networking/network-diagnostics",
    destination: "/networking/troubleshooting/network-diagnostics",
    permanent: true,
  },
  // Catch-all for /troubleshooting base path
  {
    source: "/troubleshooting",
    destination: "/",
    permanent: true,
  },
  {
    source: "/reference/s",
    destination: "/reference/templates",
    permanent: true,
  },
  {
    source: "/getting-started",
    destination: "/quick-start",
    permanent: true,
  },
  {
    source: "/develop/variables",
    destination: "/variables",
    permanent: true,
  },
  {
    source: "/develop/:slug*",
    destination: "/guides/:slug*",
    permanent: true,
  },
  {
    source: "/deploy/exposing-your-app",
    destination: "/networking/public-networking",
    permanent: true,
  },
  {
    source: "/deploy/logging",
    destination: "/observability/logs",
    permanent: true,
  },
  {
    source: "/deploy/deploy-on-railway-button",
    destination: "/templates",
    permanent: true,
  },
  {
    source: "/deploy/healthchecks",
    destination: "/deployments/healthchecks",
    permanent: true,
  },
  {
    source: "/deploy/integrations",
    destination: "/integrations/api",
    permanent: true,
  },
  {
    source: "/deploy/railway-up",
    destination: "/services",
    permanent: true,
  },
  {
    source: "/deploy/:slug*",
    destination: "/guides/:slug*",
    permanent: true,
  },
  {
    source: "/databases/bring-your-own-database",
    destination: "/databases/build-a-database-service",
    permanent: true,
  },
  {
    source: "/diagnose/project-usage",
    destination: "/projects/project-usage",
    permanent: true,
  },
  {
    source: "/diagnose/:slug*",
    destination: "/guides/:slug*",
    permanent: true,
  },
  {
    source: "/guides/migrate-from-heroku",
    destination: "/tutorials/migrate-from-heroku",
    permanent: true,
  },
  {
    source: "/reference/compare-to-heroku",
    destination: "/platform/compare-to-heroku",
    permanent: true,
  },
  {
    source: "/troubleshoot/fixing-common-errors",
    destination: "/networking/troubleshooting/application-failed-to-respond",
    permanent: true,
  },
  {
    source: "/reference/guides",
    destination: "/quick-start",
    permanent: true,
  },
  {
    source: "/reference/pricing",
    destination: "/pricing/plans",
    permanent: true,
  },
  {
    // Never a real page — but a plausible guess from the legacy /reference/*
    // IA that LLMs and old links keep producing. Send it to the pricing hub.
    source: "/reference/billing",
    destination: "/pricing",
    permanent: true,
  },
  {
    source: "/guides/fixing-common-errors",
    destination: "/networking/troubleshooting/application-failed-to-respond",
    permanent: true,
  },
  {
    source: "/reference/production-readiness-checklist",
    destination: "/overview/production-readiness-checklist",
    permanent: true,
  },
  {
    source: "/overview/about-railway",
    destination: "/platform",
    permanent: true,
  },
  {
    source: "/platform/about-railway",
    destination: "/platform",
    permanent: true,
  },
  {
    source: "/maturity/philosophy",
    destination: "/platform/philosophy",
    permanent: true,
  },
  {
    source: "/maturity/use-cases",
    destination: "/platform/use-cases",
    permanent: true,
  },
  {
    source: "/reference/support",
    destination: "/platform/support",
    permanent: true,
  },
  {
    source: "/maturity/incident-management",
    destination: "/platform/incident-management",
    permanent: true,
  },
  {
    source: "/railway-metal",
    destination: "/platform/railway-metal",
    permanent: true,
  },
  {
    source: "/maturity/compare-to-heroku",
    destination: "/platform/compare-to-heroku",
    permanent: true,
  },
  {
    source: "/maturity/compare-to-render",
    destination: "/platform/compare-to-render",
    permanent: true,
  },
  {
    source: "/maturity/compare-to-fly",
    destination: "/platform/compare-to-fly",
    permanent: true,
  },
  {
    source: "/maturity/compare-to-vercel",
    destination: "/platform/compare-to-vercel",
    permanent: true,
  },
  {
    source: "/maturity/compare-to-digitalocean",
    destination: "/platform/compare-to-digitalocean",
    permanent: true,
  },
  {
    source: "/maturity/compare-to-vps",
    destination: "/platform/compare-to-vps",
    permanent: true,
  },
  {
    source: "/reference/pricing/plans",
    destination: "/pricing/plans",
    permanent: true,
  },
  {
    source: "/reference/pricing/free-trial",
    destination: "/pricing/free-trial",
    permanent: true,
  },
  {
    source: "/reference/pricing/faqs",
    destination: "/pricing/faqs",
    permanent: true,
  },
  {
    source: "/reference/pricing/refunds",
    destination: "/pricing/refunds",
    permanent: true,
  },
  {
    source: "/reference/pricing/aws-marketplace",
    destination: "/pricing/aws-marketplace",
    permanent: true,
  },
  {
    source: "/reference/pricing/understanding-your-bill",
    destination: "/pricing/understanding-your-bill",
    permanent: true,
  },
  {
    source: "/reference/pricing/committed-spend",
    destination: "/pricing/committed-spend",
    permanent: true,
  },
  {
    source: "/reference/mcp-server",
    destination: "/ai/mcp-server",
    permanent: true,
  },
  {
    source: "/ai/remote-mcp-server",
    destination: "/ai/mcp-server",
    permanent: true,
  },
  {
    source: "/reference/accounts",
    destination: "/access/accounts",
    permanent: true,
  },
  {
    source: "/reference/two-factor-enforcement",
    destination: "/access/two-factor-enforcement",
    permanent: true,
  },
  {
    source: "/maturity/enterprise",
    destination: "/enterprise",
    permanent: true,
  },
  {
    source: "/reference/audit-logs",
    destination: "/enterprise/audit-logs",
    permanent: true,
  },
  {
    source: "/maturity/compliance",
    destination: "/enterprise/compliance",
    permanent: true,
  },
  {
    source: "/reference/saml",
    destination: "/enterprise/saml",
    permanent: true,
  },
  {
    source: "/reference/project-members",
    destination: "/projects/project-members",
    permanent: true,
  },
  {
    source: "/reference/project-usage",
    destination: "/projects/project-usage",
    permanent: true,
  },
  {
    source: "/reference/teams",
    destination: "/projects/workspaces",
    permanent: true,
  },
  {
    source: "/reference/variables",
    destination: "/variables/reference",
    permanent: true,
  },
  {
    source: "/guides/pre-deploy-command",
    destination: "/deployments/pre-deploy-command",
    permanent: true,
  },
  {
    source: "/guides/start-command",
    destination: "/deployments/start-command",
    permanent: true,
  },
  {
    source: "/guides/deployment-actions",
    destination: "/deployments/deployment-actions",
    permanent: true,
  },
  {
    source: "/guides/github-autodeploys",
    destination: "/deployments/github-autodeploys",
    permanent: true,
  },
  {
    source: "/guides/image-auto-updates",
    destination: "/deployments/image-auto-updates",
    permanent: true,
  },
  {
    source: "/guides/optimize-performance",
    destination: "/deployments/optimize-performance",
    permanent: true,
  },
  {
    source: "/guides/restart-policy",
    destination: "/deployments/restart-policy",
    permanent: true,
  },
  {
    source: "/guides/deployment-teardown",
    destination: "/deployments/deployment-teardown",
    permanent: true,
  },
  {
    source: "/guides/monorepo",
    destination: "/deployments/monorepo",
    permanent: true,
  },
  {
    source: "/guides/staged-changes",
    destination: "/deployments/staged-changes",
    permanent: true,
  },
  {
    source: "/reference/app-sleeping",
    destination: "/deployments/serverless",
    permanent: true,
  },
  {
    source: "/reference/deployments",
    destination: "/deployments/reference",
    permanent: true,
  },
  {
    source: "/reference/scaling",
    destination: "/deployments/scaling",
    permanent: true,
  },
  {
    source: "/guides/builds",
    destination: "/builds",
    permanent: true,
  },
  {
    source: "/guides/build-configuration",
    destination: "/builds/build-configuration",
    permanent: true,
  },
  {
    source: "/guides/private-registries",
    destination: "/builds/private-registries",
    permanent: true,
  },
  {
    source: "/reference/build-and-start-commands",
    destination: "/builds/build-and-start-commands",
    permanent: true,
  },
  {
    source: "/reference/railpack",
    destination: "/builds/railpack",
    permanent: true,
  },
  {
    source: "/reference/nixpacks",
    destination: "/builds/railpack",
    permanent: true,
  },
  {
    source: "/reference/functions",
    destination: "/functions",
    permanent: true,
  },
  {
    source: "/guides/databases",
    destination: "/databases",
    permanent: true,
  },
  {
    source: "/guides/build-a-database-service",
    destination: "/databases/build-a-database-service",
    permanent: true,
  },
  {
    source: "/guides/postgresql",
    destination: "/databases/postgresql",
    permanent: true,
  },
  {
    source: "/guides/mysql",
    destination: "/databases/mysql",
    permanent: true,
  },
  {
    source: "/guides/redis",
    destination: "/databases/redis",
    permanent: true,
  },
  {
    source: "/guides/mongodb",
    destination: "/databases/mongodb",
    permanent: true,
  },
  {
    source: "/guides/database-view",
    destination: "/databases/database-view",
    permanent: true,
  },
  {
    source: "/reference/databases",
    destination: "/databases/reference",
    permanent: true,
  },
  {
    source: "/guides/volumes",
    destination: "/volumes",
    permanent: true,
  },
  {
    source: "/reference/volumes",
    destination: "/volumes/reference",
    permanent: true,
  },
  {
    source: "/reference/backups",
    destination: "/volumes/backups",
    permanent: true,
  },
  {
    source: "/guides/storage-buckets",
    destination: "/storage-buckets",
    permanent: true,
  },
  {
    source: "/reference/outbound-networking",
    destination: "/networking/outbound-networking",
    permanent: true,
  },
  {
    source: "/reference/static-outbound-ips",
    destination: "/networking/static-outbound-ips",
    permanent: true,
  },
  {
    source: "/reference/edge-networking",
    destination: "/networking/edge-networking",
    permanent: true,
  },
  {
    source: "/reference/network-diagnostics",
    destination: "/networking/troubleshooting/network-diagnostics",
    permanent: true,
  },
  {
    source: "/guides/troubleshooting-ssl",
    destination: "/networking/troubleshooting/ssl",
    permanent: true,
  },
  {
    source: "/guides/observability",
    destination: "/observability",
    permanent: true,
  },
  {
    source: "/guides/config-as-code",
    destination: "/config-as-code",
    permanent: true,
  },
  {
    source: "/reference/config-as-code",
    destination: "/config-as-code/reference",
    permanent: true,
  },
  {
    source: "/guides/manage-projects",
    destination: "/integrations/api/manage-projects",
    permanent: true,
  },
  {
    source: "/guides/manage-services",
    destination: "/integrations/api/manage-services",
    permanent: true,
  },
  {
    source: "/guides/manage-deployments",
    destination: "/integrations/api/manage-deployments",
    permanent: true,
  },
  {
    source: "/guides/manage-variables",
    destination: "/integrations/api/manage-variables",
    permanent: true,
  },
  {
    source: "/reference/errors",
    destination: "/",
    permanent: true,
  },
  {
    source: "/reference/errors/application-failed-to-respond",
    destination: "/networking/troubleshooting/application-failed-to-respond",
    permanent: true,
  },
  {
    source: "/reference/errors/no-start-command-could-be-found",
    destination: "/deployments/troubleshooting/no-start-command-could-be-found",
    permanent: true,
  },
  {
    source: "/reference/errors/405-method-not-allowed",
    destination: "/networking/troubleshooting/405-method-not-allowed",
    permanent: true,
  },
  {
    source: "/reference/errors/nixpacks-was-unable-to-generate-a-build-plan",
    destination: "/builds/railpack",
    permanent: true,
  },
  {
    source: "/reference/errors/enotfound-redis-railway-internal",
    destination: "/databases/troubleshooting/enotfound-redis-railway-internal",
    permanent: true,
  },
  {
    source: "/reference/errors/postgres-corrupted-wal",
    destination: "/databases/troubleshooting/postgres-corrupted-wal",
    permanent: true,
  },
  {
    source: "/guides/nodejs-sigterm",
    destination: "/deployments/troubleshooting/nodejs-sigterm-handling",
    permanent: true,
  },
  {
    source: "/guides/deploy",
    destination: "/templates/deploy",
    permanent: true,
  },
  {
    source: "/guides/create",
    destination: "/templates/create",
    permanent: true,
  },
  {
    source: "/guides/templates-best-practices",
    destination: "/templates/best-practices",
    permanent: true,
  },
  {
    source: "/guides/publish-and-share",
    destination: "/templates/publish-and-share",
    permanent: true,
  },
  {
    source: "/tutorials/getting-started",
    destination: "/quick-start",
    permanent: true,
  },
  {
    source: "/tutorials/set-up-a-datadog-agent",
    destination: "/guides/set-up-a-datadog-agent",
    permanent: true,
  },
  {
    source: "/tutorials/deploy-an-otel-collector-stack",
    destination: "/guides/instrument-app-opentelemetry",
    permanent: true,
  },
  {
    source: "/guides/deploy-an-otel-collector-stack",
    destination: "/guides/instrument-app-opentelemetry",
    permanent: true,
  },
  {
    source: "/tutorials/add-a-cdn-using-cloudfront",
    destination: "/guides/add-a-cdn-using-cloudfront",
    permanent: true,
  },
  {
    source: "/tutorials/deploying-a-monorepo",
    destination: "/guides/deploying-a-monorepo",
    permanent: true,
  },
  {
    source: "/tutorials/set-up-a-tailscale-subnet-router",
    destination: "/guides/set-up-a-tailscale-forwarder",
    permanent: true,
  },
  {
    source: "/guides/set-up-a-tailscale-subnet-router",
    destination: "/guides/set-up-a-tailscale-forwarder",
    permanent: true,
  },
  {
    source: "/tutorials/bridge-railway-to-rds-with-tailscale",
    destination: "/guides/bridge-railway-to-rds-with-tailscale",
    permanent: true,
  },
  {
    source: "/tutorials/github-actions-post-deploy",
    destination: "/guides/github-actions-post-deploy",
    permanent: true,
  },
  {
    source: "/tutorials/github-actions-pr-environment",
    destination: "/guides/github-actions-pr-environment",
    permanent: true,
  },
  {
    source: "/tutorials/github-actions-runners",
    destination: "/guides/github-actions-runners",
    permanent: true,
  },
  {
    source: "/guides/projects",
    destination: "/projects",
    permanent: true,
  },
  {
    source: "/reference/projects",
    destination: "/projects",
    permanent: true,
  },
  {
    source: "/guides/services",
    destination: "/services",
    permanent: true,
  },
  {
    source: "/reference/services",
    destination: "/services",
    permanent: true,
  },
  {
    source: "/guides/healthchecks",
    destination: "/deployments/healthchecks",
    permanent: true,
  },
  {
    source: "/reference/healthchecks",
    destination: "/deployments/healthchecks",
    permanent: true,
  },
  {
    source: "/reference/deployment-regions",
    destination: "/deployments/regions",
    permanent: true,
  },
  {
    source: "/reference/regions",
    destination: "/deployments/regions",
    permanent: true,
  },
  {
    source: "/guides/dockerfiles",
    destination: "/builds/dockerfiles",
    permanent: true,
  },
  {
    source: "/reference/dockerfiles",
    destination: "/builds/dockerfiles",
    permanent: true,
  },
  {
    source: "/guides/cron-jobs",
    destination: "/cron-jobs",
    permanent: true,
  },
  {
    source: "/reference/cron-jobs",
    destination: "/cron-jobs",
    permanent: true,
  },
  {
    source: "/guides/public-networking",
    destination: "/networking/public-networking",
    permanent: true,
  },
  {
    source: "/reference/public-networking",
    destination: "/networking/public-networking",
    permanent: true,
  },
  {
    source: "/reference/public-domains",
    destination: "/networking/domains",
    permanent: true,
  },
  {
    source: "/reference/tcp-proxy",
    destination: "/networking/tcp-proxy",
    permanent: true,
  },
  {
    source: "/guides/private-networking",
    destination: "/networking/private-networking",
    permanent: true,
  },
  {
    source: "/reference/private-networking",
    destination: "/networking/private-networking",
    permanent: true,
  },
  {
    source: "/guides/logs",
    destination: "/observability/logs",
    permanent: true,
  },
  {
    source: "/reference/logging",
    destination: "/observability/logs",
    permanent: true,
  },
  {
    source: "/guides/metrics",
    destination: "/observability/metrics",
    permanent: true,
  },
  {
    source: "/reference/metrics",
    destination: "/observability/metrics",
    permanent: true,
  },
  {
    source: "/guides/webhooks",
    destination: "/observability/webhooks",
    permanent: true,
  },
  {
    source: "/reference/webhooks",
    destination: "/observability/webhooks",
    permanent: true,
  },
  {
    source: "/guides/environments",
    destination: "/environments",
    permanent: true,
  },
  {
    source: "/reference/environments",
    destination: "/environments",
    permanent: true,
  },
  {
    source: "/guides/public-api",
    destination: "/integrations/api",
    permanent: true,
  },
  {
    source: "/reference/public-api",
    destination: "/integrations/api",
    permanent: true,
  },
  // Bare /api — a common guess for the Public API reference (agents, links)
  {
    source: "/api",
    destination: "/integrations/api",
    permanent: true,
  },
  {
    source: "/api.md",
    destination: "/integrations/api.md",
    permanent: true,
  },
  {
    source: "/api-reference",
    destination: "/integrations/api",
    permanent: true,
  },
  {
    source: "/public-api",
    destination: "/integrations/api",
    permanent: true,
  },
  {
    source: "/reference/api",
    destination: "/integrations/api",
    permanent: true,
  },
  {
    source: "/guides/templates",
    destination: "/templates",
    permanent: true,
  },
  {
    source: "/reference/templates",
    destination: "/templates",
    permanent: true,
  },
  {
    source: "/reference/priority-boarding",
    destination: "/platform/priority-boarding",
    permanent: true,
  },
  {
    source: "/guides/join-priority-boarding",
    destination: "/platform/priority-boarding",
    permanent: true,
  },
  {
    source: "/guides/optimize-usage",
    destination: "/pricing/cost-control",
    permanent: true,
  },
  {
    source: "/reference/usage-limits",
    destination: "/pricing/cost-control",
    permanent: true,
  },
  {
    source: "/guides/cli",
    destination: "/cli",
    permanent: true,
  },
  {
    source: "/reference/cli-api",
    destination: "/cli",
    permanent: true,
  },
  {
    source: "/migration/migrate-from-heroku",
    destination: "/platform/migrate-from-heroku",
    permanent: true,
  },
  {
    source: "/migration/migrate-from-render",
    destination: "/platform/migrate-from-render",
    permanent: true,
  },
  {
    source: "/migration/migrate-from-fly",
    destination: "/platform/migrate-from-fly",
    permanent: true,
  },
  {
    source: "/migration/migrate-from-vercel",
    destination: "/platform/migrate-from-vercel",
    permanent: true,
  },
  {
    source: "/migration/migrate-from-digitalocean",
    destination: "/platform/migrate-from-digitalocean",
    permanent: true,
  },
  {
    source: "/guides/foundations",
    destination: "/overview/the-basics",
    permanent: true,
  },
  {
    source: "/guides/networking",
    destination: "/networking",
    permanent: true,
  },
  {
    source: "/guides/monitoring",
    destination: "/observability",
    permanent: true,
  },
  {
    source: "/guides/deployments",
    destination: "/deployments",
    permanent: true,
  },
  {
    source: "/guides/healthchecks-and-restarts",
    destination: "/deployments/healthchecks",
    permanent: true,
  },
  {
    source: "/reference/migrate-to-railway-metal",
    destination: "/",
    permanent: true,
  },
  {
    source: "/guides/variables",
    destination: "/variables",
    permanent: true,
  },
  // Legacy root-level pages superseded by /networking/* hierarchy
  {
    source: "/private-networking",
    destination: "/networking/private-networking",
    permanent: true,
  },
  {
    source: "/public-networking",
    destination: "/networking/public-networking",
    permanent: true,
  },
  // Serverless redirect (previously app-sleeping)
  {
    source: "/deployments/app-sleeping",
    destination: "/deployments/serverless",
    permanent: true,
  },
  {
    source: "/reference/integrations",
    destination: "/integrations/api",
    permanent: true,
  },
  {
    source: "/guides/troubleshooting-slow-apps",
    destination: "/deployments/troubleshooting/slow-deployments",
    permanent: true,
  },
  {
    source: "/guides/troubleshooting-slow-deployments",
    destination: "/deployments/troubleshooting/slow-deployments",
    permanent: true,
  },
  {
    source: "/guides/manage-domains",
    destination: "/integrations/api/manage-domains",
    permanent: true,
  },
  {
    source: "/guides/manage-environments",
    destination: "/integrations/api/manage-environments",
    permanent: true,
  },
  {
    source: "/guides/manage-volumes",
    destination: "/integrations/api/manage-volumes",
    permanent: true,
  },
  // OAuth redirects (from old live URLs)
  {
    source: "/reference/oauth/login-with-railway",
    destination: "/integrations/oauth",
    permanent: true,
  },
  {
    source: "/reference/oauth/:slug*",
    destination: "/integrations/oauth/:slug*",
    permanent: true,
  },
  // Guides redirects
  {
    source: "/guides/graphql-overview",
    destination: "/integrations/api/graphql-overview",
    permanent: true,
  },
  {
    source: "/guides/api-cookbook",
    destination: "/integrations/api/api-cookbook",
    permanent: true,
  },
  {
    source: "/guides/languages-frameworks",
    destination: "/languages-frameworks",
    permanent: true,
  },
  {
    source: "/reference/workspaces",
    destination: "/projects/workspaces",
    permanent: true,
  },
  {
    source: "/builds/nixpacks",
    destination: "/builds/railpack",
    permanent: true,
  },
  {
    source: "/builds/troubleshooting/nixpacks-was-unable-to-generate-a-build-plan",
    destination: "/builds/railpack",
    permanent: true,
  },
  {
    source: "/cloud-agents/getting-started",
    destination: "/cloud-agents",
    permanent: true,
  },
];

const hashRedirects = [
  {
    source: "#application-failed-to-respond",
    destination: "/reference/errors/application-failed-to-respond",
    permanent: true,
  },
  {
    source: "#post-requests-turn-into-get-requests",
    destination: "/reference/errors/405-method-not-allowed",
    permanent: true,
  },
  {
    source: "/guides/healthchecks-and-restarts#restart-policy",
    destination: "/guides/restart-policy",
    permanent: true,
  },
  {
    source: "/guides/healthchecks-and-restarts#configure-healthcheck-path",
    destination: "/guides/healthchecks#configure-the-healthcheck-path",
    permanent: true,
  },
  {
    source: "/guides/healthchecks-and-restarts#configure-healthcheck-port",
    destination: "/guides/healthchecks#configure-the-healthcheck-port",
    permanent: true,
  },
  {
    source: "/guides/healthchecks-and-restarts#healthcheck-timeout",
    destination: "/guides/healthchecks#healthcheck-timeout",
    permanent: true,
  },
  {
    source: "/guides/healthchecks-and-restarts#services-with-attached-volumes",
    destination: "/guides/healthchecks#services-with-attached-volumes",
    permanent: true,
  },
  {
    source: "/guides/healthchecks-and-restarts#healthcheck-hostname",
    destination: "/guides/healthchecks#healthcheck-hostname",
    permanent: true,
  },
  {
    source: "/guides/healthchecks-and-restarts#continuous-healthchecks",
    destination: "/guides/healthchecks#continuous-healthchecks",
    permanent: true,
  },
];

module.exports = {
  redirects,
  hashRedirects,
};
