import * as React from "react";
import {
  generateDefaultSeo,
  generateNextSeo,
  NextSeoProps,
  DefaultSeoProps,
} from "next-seo/pages";
import Head from "next/head";
import { useRouter } from "next/router";
import { Header, FAQItem, safeJsonLdStringify } from "@/utils/seo";
import { pageUrlSet } from "@/utils/page-url-set";

export interface Props extends NextSeoProps {
  title?: string;
  twitterTitle?: string;
  description?: string;
  image?: string;
  url?: string;
  headers?: Header[];
  faqItems?: FAQItem[];
  breadcrumbs?: Array<{ name: string; url?: string }>;
  lastModified?: string;
  author?: string;
  publishedTime?: string;
  headline?: string;
  noArticleSchema?: boolean;
}

const title = "Railway Docs";
const description = "Documentation for Railway";

export const baseUrl = "https://docs.railway.com";
const defaultImage = baseUrl + "/og-docs.png";

const config: DefaultSeoProps = {
  title,
  description,
  openGraph: {
    type: "website",
    url: baseUrl,
    site_name: title,
    images: [
      { url: defaultImage, width: 1200, height: 630, type: "image/png" },
    ],
  },
  twitter: {
    site: "@Railway",
    handle: "@Railway",
    cardType: "summary_large_image",
  },
};

export const SEO: React.FC<Props> = ({
  image,
  headers = [],
  faqItems = [],
  breadcrumbs = [],
  lastModified,
  author = "Railway",
  publishedTime,
  headline,
  noArticleSchema,
  ...props
}) => {
  const router = useRouter();
  const title = props.title ?? config.title;
  const twitterTitle = props.twitterTitle;
  const description = props.description;
  const url =
    props.url || `${baseUrl}${router.asPath.split("?")[0].split("#")[0]}`;
  const nextSeo = {
    ...props,
    canonical: url,
    ...(image == null
      ? {}
      : {
          openGraph: {
            url,
            description,
            site_name: title,
            images: [{ url: image }],
            type: "article",
            ...(publishedTime && { publishedTime }),
            ...(lastModified && { modifiedTime: lastModified }),
          },
        }),
  };

  // Build structured data schemas
  const schemas: Record<string, any>[] = [];

  // Organization schema
  const organizationSchema = {
    "@context": "https://schema.org",
    "@type": "Organization",
    name: "Railway",
    url: "https://railway.com",
    logo: "https://railway.com/brand/logo-dark.png",
    // Kept in step with ORGANIZATION_SCHEMA on railway.com: two different
    // machine-readable claims about one entity weaken the entity consolidation
    // that answer engines rely on to resolve "Railway".
    sameAs: [
      "https://twitter.com/railway",
      "https://github.com/railwayapp",
      "https://discord.gg/railway",
      "https://www.youtube.com/@railwayapp",
    ],
  };
  schemas.push(organizationSchema);

  // BreadcrumbList schema
  if (breadcrumbs.length > 0) {
    const breadcrumbSchema = {
      "@context": "https://schema.org",
      "@type": "BreadcrumbList",
      itemListElement: breadcrumbs.map((crumb, index) => ({
        "@type": "ListItem",
        position: index + 1,
        name: crumb.name,
        item: crumb.url ? `${baseUrl}${crumb.url}` : undefined,
      })),
    };
    schemas.push(breadcrumbSchema);
  }

  // Table of Contents schema (using ItemList)
  if (headers.length > 0) {
    const tocSchema = {
      "@context": "https://schema.org",
      "@type": "ItemList",
      name: "Table of Contents",
      itemListElement: headers.map((header, index) => ({
        "@type": "ListItem",
        position: index + 1,
        name: header.title,
        url: url ? `${url}#${header.id}` : undefined,
      })),
    };
    schemas.push(tocSchema);
  }

  // Article schema
  if (!noArticleSchema) {
    const articleSchema = {
      "@context": "https://schema.org",
      "@type": "Article",
      headline: headline || title,
      description: description,
      url: url,
      author: {
        "@type": "Organization",
        name: author,
      },
      publisher: {
        "@type": "Organization",
        name: "Railway",
        logo: {
          "@type": "ImageObject",
          url: "https://railway.com/brand/logo-dark.png",
        },
      },
      ...(publishedTime && { datePublished: publishedTime }),
      ...(lastModified && { dateModified: lastModified }),
      ...(image && {
        image: {
          "@type": "ImageObject",
          url: image,
        },
      }),
    };
    schemas.push(articleSchema);
  }

  // FAQPage schema — only when real answer text is available
  if (faqItems.length > 0) {
    const faqSchema = {
      "@context": "https://schema.org",
      "@type": "FAQPage",
      mainEntity: faqItems.map(faq => ({
        "@type": "Question",
        name: faq.question,
        acceptedAnswer: {
          "@type": "Answer",
          text: faq.answer,
        },
      })),
    };
    schemas.push(faqSchema);
  }

  // Build enhanced meta tags from section hierarchy
  const sectionMetaTags: React.ReactNode[] = [];
  if (breadcrumbs.length > 1) {
    // Add section information
    const sectionName = breadcrumbs[breadcrumbs.length - 2]?.name;
    if (sectionName) {
      sectionMetaTags.push(
        <meta
          key="article:section"
          property="article:section"
          content={sectionName}
        />,
      );
    }
  }

  // Add tags based on breadcrumb hierarchy
  if (breadcrumbs.length > 2) {
    const tags = breadcrumbs
      .slice(1, -1)
      .map(crumb => crumb.name)
      .filter(Boolean);
    tags.forEach((tag, index) => {
      sectionMetaTags.push(
        <meta
          key={`article:tag-${index}`}
          property="article:tag"
          content={tag}
        />,
      );
    });
  }

  return (
    <>
      <Head>
        {generateDefaultSeo(config)}
        {generateNextSeo(nextSeo)}
        <title>{title}</title>
        <meta name="twitter:title" content={twitterTitle} />
        <meta name="twitter:description" content={description} />
        <meta name="twitter:image" content={image ?? defaultImage} />
        <meta name="twitter:image:alt" content={twitterTitle} />

        {/* Enhanced meta tags from section hierarchy */}
        {sectionMetaTags}

        {/* Last modification date */}
        {lastModified && <meta name="last-modified" content={lastModified} />}

        {/* Markdown alternate for LLM/agent discovery — only when the .md exists */}
        {pageUrlSet.has(router.asPath.split("?")[0].split("#")[0]) && (
          <link rel="alternate" type="text/markdown" href={`${url}.md`} />
        )}

        {/* Structured data schemas */}
        {schemas.map((schema, index) => (
          <script
            key={`schema-${index}`}
            type="application/ld+json"
            dangerouslySetInnerHTML={{ __html: safeJsonLdStringify(schema) }}
          />
        ))}
      </Head>
    </>
  );
};
