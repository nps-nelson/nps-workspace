import { useRouter } from "next/router";
import React, { useMemo, useState, useEffect, useRef } from "react";
import { cn } from "@/lib/cn";
import { sidebarContent } from "../data/sidebar";
import { Link } from "./link";
import { IPage, ISubSection, IExternalLink, ISidebarSection } from "../types";
import SidebarItem from "./sidebar-item";
import { containingSubsectionSlugs, sidebarItemContainsPage } from "@/utils/sidebar";
import { Arrow } from "@/components/arrow";

export const Sidebar: React.FC = ({ ...props }) => {
  const scrollContainerRef = useRef<HTMLDivElement>(null);
  const [scrollState, setScrollState] = useState({
    canScrollUp: false,
    canScrollDown: false,
  });

  useEffect(() => {
    const container = scrollContainerRef.current;
    if (!container) return;

    const updateScrollState = () => {
      const { scrollTop, scrollHeight, clientHeight } = container;
      setScrollState({
        canScrollUp: scrollTop > 0,
        canScrollDown: scrollTop + clientHeight < scrollHeight - 1,
      });
    };

    updateScrollState();
    container.addEventListener("scroll", updateScrollState);

    const resizeObserver = new ResizeObserver(updateScrollState);
    resizeObserver.observe(container);

    return () => {
      container.removeEventListener("scroll", updateScrollState);
      resizeObserver.disconnect();
    };
  }, []);

  return (
    <div
      className="sidebar hidden md:flex md:flex-col md:sticky md:top-[53px] md:h-[calc(100vh-53px)] md:overflow-hidden md:w-sidebar md:shrink-0 md:border-r md:border-muted bg-muted-app"
      {...props}
    >
      <div className="relative flex-1 min-h-0 overflow-hidden">
        {/* Top fade indicator */}
        <div
          className={cn(
            "from-muted-app pointer-events-none absolute inset-x-0 top-0 z-10 h-6 bg-gradient-to-b to-transparent transition-opacity duration-150",
            scrollState.canScrollUp ? "opacity-100" : "opacity-0",
          )}
          aria-hidden="true"
        />

        {/* Scrollable container */}
        <div
          ref={scrollContainerRef}
          className="h-full overflow-y-auto pl-6 pr-3 pt-10 pb-4"
        >
          <SidebarContent />
        </div>

        {/* Bottom fade indicator */}
        <div
          className={cn(
            "from-muted-app pointer-events-none absolute inset-x-0 bottom-0 z-10 h-6 bg-gradient-to-t to-transparent transition-opacity duration-150",
            scrollState.canScrollDown ? "opacity-100" : "opacity-0",
          )}
          aria-hidden="true"
        />
      </div>
    </div>
  );
};

const SidebarContent: React.FC = () => {
  const {
    query: { slug },
    pathname,
  } = useRouter();

  const prefixedSlug = useMemo(
    () => (slug ? `/${(slug as string[] | undefined)?.join("/")}` : undefined),
    [slug],
  );

  const [expandedSubSections, setExpandedSubSections] = useState<string[]>([]);
  const [expandedSections, setExpandedSections] = useState<string[]>(() => {
    // Initialize with sections marked defaultExpanded
    return sidebarContent
      .filter(s => s.defaultExpanded && s.title)
      .map(s => s.title!);
  });
  const activeLinkRef = React.useRef<HTMLAnchorElement | null>(null);

  const currentSlug = prefixedSlug ?? pathname;

  // Auto-expand section containing current page
  useEffect(() => {
    const containingSection = sidebarContent.find(
      section =>
        section.title &&
        section.content.some(item => sidebarItemContainsPage(item, currentSlug)),
    );

    if (containingSection?.title) {
      setExpandedSections(prev =>
        prev.includes(containingSection.title!)
          ? prev
          : [...prev, containingSection.title!],
      );
    }
  }, [currentSlug]);

  useEffect(() => {
    const newExpandedSubSections = sidebarContent.flatMap(section =>
      containingSubsectionSlugs(section.content, currentSlug),
    );
    setExpandedSubSections(prevExpandedSubSections =>
      Array.from(
        new Set([...prevExpandedSubSections, ...newExpandedSubSections]),
      ),
    );
  }, [currentSlug]);

  useEffect(() => {
    if (activeLinkRef.current) {
      activeLinkRef.current.scrollIntoView({
        block: "nearest",
        behavior: "smooth",
      });
    }
  }, [prefixedSlug]);

  const isCurrentPage = (pageSlug: string) =>
    (prefixedSlug ?? pathname) === pageSlug;

  const isCurrentSection = (section: ISidebarSection) =>
    section.content.some(item => sidebarItemContainsPage(item, currentSlug));

  const toggleSubSection = (subTitleSlug: string) => {
    setExpandedSubSections(prevState =>
      prevState.includes(subTitleSlug)
        ? prevState.filter(slug => slug !== subTitleSlug)
        : [...prevState, subTitleSlug],
    );
  };

  const toggleSection = (sectionTitle: string) => {
    setExpandedSections(prevState =>
      prevState.includes(sectionTitle)
        ? prevState.filter(title => title !== sectionTitle)
        : [...prevState, sectionTitle],
    );
  };

  const renderContentItem = (item: IPage | ISubSection | IExternalLink) => {
    let itemSlug = "";

    if ("slug" in item) {
      itemSlug = item.slug;
    } else if ("subTitle" in item) {
      itemSlug =
        typeof item.subTitle === "string" ? item.subTitle : item.subTitle.slug;
    } else if ("url" in item) {
      itemSlug = item.url;
    }

    return (
      <SidebarItem
        key={itemSlug}
        item={item}
        currentSlug={currentSlug}
        isCurrentPage={isCurrentPage}
        isExpanded={expandedSubSections.includes(itemSlug)}
        onToggleSubSection={() => toggleSubSection(itemSlug)}
        activeLinkRef={activeLinkRef}
        expandedSubSections={expandedSubSections}
        onToggleNestedSection={toggleSubSection}
      />
    );
  };

  return (
    <>
      {sidebarContent.map((section, i) => {
        return (
          <React.Fragment key={i}>
            {/* Sections without a title - render links directly */}
            {!section.title && section.content.length > 0 && (
              <>
                <ul className="space-y-0.5 min-w-0 pb-6">
                  {section.content.map(renderContentItem)}
                </ul>
                <hr className="border-muted mb-6" />
              </>
            )}
            {/* Named sections */}
            {section.title && (
              <>
                {/* Section with no content and has a slug - render as plain link */}
                {section.slug && section.content.length === 0 ? (
                  <Link
                    href={section.slug}
                    className={cn(
                      "group flex w-full items-center gap-2 py-1.5 px-3 -ml-3 rounded-md min-w-0",
                      "text-sm text-muted-base",
                      "hover:text-muted-high-contrast transition-colors",
                      "focus:outline-none focus-visible:ring-2 focus-visible:ring-primary-solid focus-visible:ring-offset-2 focus-visible:ring-offset-muted-app",
                      isCurrentPage(section.slug) &&
                        "bg-primary-element-active text-muted-high-contrast font-medium",
                    )}
                    title={section.title}
                  >
                    <span className="truncate">{section.title}</span>
                  </Link>
                ) : (
                  /* Section with content - collapsible accordion */
                  <>
                    {section.slug ? (
                      /* A link must not nest inside a button; render the row
                         with the link and the expand toggle as siblings. */
                      <div
                        className={cn(
                          "group flex w-full items-center justify-between gap-2 py-1.5 px-3 -ml-3 rounded-md min-w-0",
                          "text-sm text-muted-base",
                          "hover:text-muted-high-contrast transition-colors",
                          isCurrentSection(section) &&
                            "text-muted-high-contrast font-medium current-section",
                          isCurrentPage(section.slug) &&
                            "bg-primary-element-active text-muted-high-contrast font-medium",
                        )}
                      >
                        <Link
                          href={section.slug}
                          className={cn(
                            "flex-1 text-left truncate min-w-0 -my-1.5 py-1.5",
                            "focus:outline-none focus-visible:ring-2 focus-visible:ring-primary-solid focus-visible:ring-inset rounded",
                            isCurrentPage(section.slug) &&
                              "text-muted-high-contrast font-medium",
                          )}
                          onClick={e => {
                            if (isCurrentPage(section.slug!)) {
                              // Already on this page, toggle collapse/expand
                              e.preventDefault();
                              toggleSection(section.title!);
                            } else if (
                              !expandedSections.includes(section.title!)
                            ) {
                              // Navigating to a new page, expand the section
                              setExpandedSections(prev => [
                                ...prev,
                                section.title!,
                              ]);
                            }
                          }}
                          title={section.title}
                        >
                          {section.title}
                        </Link>
                        <button
                          type="button"
                          onClick={() => toggleSection(section.title!)}
                          aria-expanded={expandedSections.includes(
                            section.title,
                          )}
                          aria-label={
                            expandedSections.includes(section.title)
                              ? `Collapse ${section.title} section`
                              : `Expand ${section.title} section`
                          }
                          className="flex size-7 -my-1 shrink-0 cursor-pointer items-center justify-center rounded-md focus:outline-none focus-visible:ring-2 focus-visible:ring-primary-solid"
                        >
                          <Arrow
                            isExpanded={expandedSections.includes(
                              section.title,
                            )}
                            className="shrink-0 group-hover:text-muted-high-contrast"
                          />
                        </button>
                      </div>
                    ) : (
                      <button
                        type="button"
                        onClick={() => toggleSection(section.title!)}
                        className={cn(
                          "group flex w-full items-center justify-between gap-2 py-1.5 px-3 -ml-3 rounded-md cursor-pointer min-w-0",
                          "text-sm text-muted-base",
                          "hover:text-muted-high-contrast transition-colors",
                          "focus:outline-none focus-visible:ring-2 focus-visible:ring-primary-solid focus-visible:ring-offset-2 focus-visible:ring-offset-muted-app",
                          isCurrentSection(section) &&
                            "text-muted-high-contrast font-medium current-section",
                        )}
                        aria-expanded={expandedSections.includes(section.title)}
                        aria-label={
                          expandedSections.includes(section.title)
                            ? `Collapse ${section.title} section`
                            : `Expand ${section.title} section`
                        }
                      >
                        <span
                          className="flex-1 text-left truncate min-w-0"
                          title={section.title}
                        >
                          {section.title}
                        </span>
                        <Arrow
                          isExpanded={expandedSections.includes(section.title)}
                          className="shrink-0 group-hover:text-muted-high-contrast"
                        />
                      </button>
                    )}

                    <div
                      className={cn(
                        "grid transition-[grid-template-rows] duration-200 ease-out",
                        expandedSections.includes(section.title)
                          ? "grid-rows-[1fr]"
                          : "grid-rows-[0fr]",
                      )}
                    >
                      <ul
                        className={cn(
                          "overflow-hidden ml-3 pl-3 space-y-0.5 min-w-0",
                          expandedSections.includes(section.title)
                            ? "pt-1 pb-2 border-l border-muted"
                            : "",
                        )}
                      >
                        {section.content.map(renderContentItem)}
                      </ul>
                    </div>
                  </>
                )}
              </>
            )}
          </React.Fragment>
        );
      })}
    </>
  );
};

export const MobileSidebar: React.FC<{ isOpen: boolean }> = ({ isOpen }) => {
  return (
    <div
      className={cn(isOpen ? "block" : "hidden", "w-full md:hidden px-4 pb-6")}
    >
      <SidebarContent />
    </div>
  );
};
