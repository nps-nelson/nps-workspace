import { IPage, ISidebarContent } from "../types";
import { slugify } from "@/utils/slugify";

const makePage = (title: string, category?: string, slug?: string): IPage => ({
  title,
  category,
  slug: (() => {
    if (slug) {
      return slug.startsWith("/") ? slug : "/" + slug;
    }

    return "/" + (category ? category + "/" : "") + slugify(title);
  })(),
});

const makeCliCommand = (commandName: string): IPage => ({
  title: commandName,
  commandName,
  category: "cli",
  slug: "/cli/" + commandName,
});

export const sidebarContent: ISidebarContent = [
  {
    content: [
      makePage("Quick start", undefined, "/quick-start"),
      makePage("The basics", "overview"),
      makePage("Railway for Agents", undefined, "/agents"),
      makePage("Mobile app", undefined, "/mobile-app"),
      makePage("Best practices", "overview"),
      makePage("Advanced concepts", "overview"),
      makePage("Production readiness checklist", "overview"),
      makePage("Guides", undefined, "/guides"),
      makePage("Keyboard shortcuts", "overview"),
    ],
  },
  {
    title: "Platform",
    slug: "/platform",
    content: [
      makePage("Philosophy", "platform"),
      makePage("Use cases", "platform"),
      makePage("Support", "platform"),
      makePage("Incident management", "platform"),
      makePage("Railway Metal", "platform"),
      makePage("Priority boarding", "platform"),
      {
        subTitle: "Compare to Railway",
        pages: [
          makePage("Compare to Heroku", "platform"),
          makePage("Compare to Render", "platform"),
          makePage("Compare to Fly", "platform"),
          makePage("Compare to Northflank", "platform"),
          makePage("Compare to Vercel", "platform"),
          makePage("Compare to DigitalOcean", "platform"),
          makePage("Compare to Replit", "platform"),
          makePage("Compare to Lovable", "platform"),
          makePage("Compare to Bolt", "platform"),
          makePage("Compare to VPS", "platform"),
        ],
      },
      {
        subTitle: "Migrate to Railway",
        pages: [
          makePage("Migrate from Heroku", "platform"),
          makePage("Migrate from Render", "platform"),
          makePage("Migrate from Fly", "platform"),
          makePage("Migrate from Vercel", "platform"),
          makePage("Migrate from DigitalOcean", "platform"),
          makePage("Migrate from Replit", "platform"),
          makePage("Migrate from Lovable", "platform"),
          makePage("Migrate from Bolt", "platform"),
        ],
      },
    ],
  },

  {
    title: "Pricing",
    slug: "/pricing",
    content: [
      makePage("Plans", "pricing"),
      makePage("Free trial", "pricing"),
      makePage("Understanding your bill", "pricing"),
      makePage("FAQs", "pricing"),
      makePage("Refunds", "pricing"),
      makePage("Cost control", "pricing"),
      makePage("Committed spend", "pricing"),
      makePage("AWS Marketplace", "pricing"),
      makePage("Credits", "pricing"),
    ],
  },
  // Enterprise
  {
    title: "Enterprise",
    slug: "/enterprise",
    content: [
      makePage("Compliance", "enterprise"),
      makePage("Audit logs", "enterprise"),
      makePage("SAML SSO", "enterprise", "/enterprise/saml"),
      makePage("Access groups", "enterprise"),
      makePage("Environment RBAC", "enterprise"),
      makePage("Guardrails", "enterprise"),
    ],
  },
  {
    title: "AI",
    slug: "/ai",
    content: [
      {
        subTitle: makePage("Cloud agents", undefined, "/cloud-agents"),
        pages: [
          makePage("Quickstart", undefined, "/cloud-agents/quickstart"),
          makePage("Terminal sessions", undefined, "/cloud-agents/terminal"),
          makePage("Herdr", undefined, "/cloud-agents/herdr"),
          makePage("Claude Desktop", undefined, "/cloud-agents/claude"),
          makePage("Codex Desktop", undefined, "/cloud-agents/codex"),
          makePage("OpenCode", undefined, "/cloud-agents/opencode"),
          makePage("Agents and sessions", undefined, "/cloud-agents/manage"),
          makePage(
            "Credentials and configuration",
            undefined,
            "/cloud-agents/configuration",
          ),
          makePage(
            "Troubleshooting",
            undefined,
            "/cloud-agents/troubleshooting",
          ),
        ],
      },
      makePage("Railway Agent", "ai"),
      makePage("Agent Connectors", "ai"),
      makePage("Bring Your Own Models", "ai"),
      {
        subTitle: makePage("Agent integrations", undefined, "/ai/agent-integrations"),
        pages: [
          makePage("Slack", "ai/agent-integrations"),
          makePage("Discord", "ai/agent-integrations"),
        ],
      },
      makePage("Agent skills", "ai"),
      {
        subTitle: makePage(
          "Plugins and connectors",
          undefined,
          "/ai/plugins-and-connectors",
        ),
        pages: [
          makePage("ChatGPT plugin", "ai"),
          makePage("Codex plugin", "ai"),
          makePage("Claude connector", "ai"),
          makePage("Claude Code plugin", "ai"),
          makePage("Grok Build plugin", "ai"),
          makePage("Grok Bot plugin", "ai"),
          makePage("Cursor plugin", "ai"),
        ],
      },
      makePage("MCP server", "ai"),
    ],
  },
  {
    title: "Templates & open source",
    slug: "/templates",
    content: [
      {
        subTitle: "Using templates",
        pages: [
          makePage("Deploy", "templates"),
          makePage("Create", "templates"),
          makePage("Updates", "templates"),
          makePage("Best practices", "templates", "/templates/best-practices"),
          makePage(
            "High availability",
            "templates",
            "/templates/high-availability",
          ),
          makePage("Publish and share", "templates"),
        ],
      },
      {
        subTitle: "Monetizing templates",
        pages: [
          makePage("Kickbacks", "templates"),
          makePage("Private Docker images", "templates"),
          makePage("Metrics", "templates"),
        ],
      },
      makePage("Open source technology partners", "templates", "/templates/partners"),
    ],
  },
  {
    title: "Languages & frameworks",
    slug: "/languages-frameworks",
    content: [
      {
        subTitle: "JavaScript / TypeScript",
        pages: [
          makePage("Next.js", "guides", "/guides/nextjs"),
          makePage("Express", "guides", "/guides/express"),
          makePage("Hono", "guides", "/guides/hono"),
          makePage("Fastify", "guides", "/guides/fastify"),
          makePage("Nest.js", "guides", "/guides/nest"),
          makePage("Remix", "guides", "/guides/remix"),
          makePage("Nuxt", "guides", "/guides/nuxt"),
          makePage("Astro", "guides", "/guides/astro"),
          makePage("SvelteKit", "guides", "/guides/sveltekit"),
          makePage("Bun", "guides", "/guides/bun"),
          makePage("React", "guides", "/guides/react"),
          makePage("Vue", "guides", "/guides/vue"),
          makePage("Angular", "guides", "/guides/angular"),
          makePage("Solid", "guides", "/guides/solid"),
          makePage("Sails", "guides", "/guides/sails"),
          makePage("Gatsby", "guides", "/guides/gatsby"),
          makePage("TanStack Start", "guides", "/guides/tanstack-start"),
        ],
      },
      {
        subTitle: "Python",
        pages: [
          makePage("FastAPI", "guides", "/guides/fastapi"),
          makePage("Flask", "guides", "/guides/flask"),
          makePage("Django", "guides", "/guides/django"),
        ],
      },
      {
        subTitle: "PHP",
        pages: [
          makePage("Laravel", "guides", "/guides/laravel"),
          makePage("Symfony", "guides", "/guides/symfony"),
        ],
      },
      {
        subTitle: "Ruby",
        pages: [makePage("Rails", "guides", "/guides/rails")],
      },
      {
        subTitle: "Go",
        pages: [
          makePage("Gin", "guides", "/guides/gin"),
          makePage("Go Fiber", "guides", "/guides/go-fiber"),
          makePage("Beego", "guides", "/guides/beego"),
        ],
      },
      {
        subTitle: "Rust",
        pages: [
          makePage("Axum", "guides", "/guides/axum"),
          makePage("Actix Web", "guides", "/guides/actix-web"),
          makePage("Rocket", "guides", "/guides/rocket"),
        ],
      },
      {
        subTitle: "Java",
        pages: [makePage("Spring Boot", "guides", "/guides/spring-boot")],
      },
      {
        subTitle: "Kotlin",
        pages: [makePage("Ktor", "guides", "/guides/ktor")],
      },
      {
        subTitle: "C#",
        pages: [makePage("ASP.NET Core", "guides", "/guides/aspnet-core")],
      },
      {
        subTitle: "Scala",
        pages: [makePage("Play", "guides", "/guides/play")],
      },
      {
        subTitle: "Elixir",
        pages: [
          makePage("Phoenix", "guides", "/guides/phoenix"),
          makePage(
            "Phoenix + Distillery",
            "guides",
            "/guides/phoenix-distillery",
          ),
        ],
      },
      {
        subTitle: "Clojure",
        pages: [makePage("Luminus", "guides", "/guides/luminus")],
      },
    ],
  },
  {
    title: "CLI",
    slug: "/cli",
    content: [
      makePage("Global options", "cli"),
      makePage("Deploying", "cli"),
      makePage("Telemetry", "cli"),
      makeCliCommand("add"),
      makeCliCommand("agent"),
      makeCliCommand("api"),
      makeCliCommand("autoupdate"),
      makeCliCommand("bucket"),
      makeCliCommand("ca"),
      makeCliCommand("cdn"),
      makeCliCommand("code"),
      makeCliCommand("completion"),
      makeCliCommand("config"),
      makeCliCommand("connect"),
      makeCliCommand("delete"),
      makeCliCommand("deploy"),
      makeCliCommand("deployment"),
      makeCliCommand("dev"),
      makeCliCommand("docs"),
      makeCliCommand("domain"),
      makeCliCommand("down"),
      makeCliCommand("environment"),
      makeCliCommand("flag"),
      makeCliCommand("functions"),
      makeCliCommand("init"),
      makeCliCommand("link"),
      makeCliCommand("list"),
      makeCliCommand("login"),
      makeCliCommand("logout"),
      makeCliCommand("logs"),
      makeCliCommand("mcp"),
      makeCliCommand("metrics"),
      makeCliCommand("open"),
      makeCliCommand("outbound-network"),
      makeCliCommand("postgres"),
      makeCliCommand("project"),
      makeCliCommand("private-network"),
      makeCliCommand("redeploy"),
      makeCliCommand("restart"),
      makeCliCommand("run"),
      makeCliCommand("sandbox"),
      makeCliCommand("scale"),
      makeCliCommand("service"),
      makeCliCommand("setup"),
      makeCliCommand("shell"),
      makeCliCommand("skills"),
      makeCliCommand("ssh"),
      makeCliCommand("starship"),
      makeCliCommand("status"),
      makeCliCommand("templates"),
      makeCliCommand("tcp-proxy"),
      makeCliCommand("trace"),
      makeCliCommand("unlink"),
      makeCliCommand("up"),
      makeCliCommand("upgrade"),
      makeCliCommand("usage"),
      makeCliCommand("variable"),
      makeCliCommand("volume"),
      makeCliCommand("waf"),
      makeCliCommand("whoami"),
    ],
  },
  {
    title: "Projects",
    slug: "/projects",
    content: [
      makePage("Project members", "projects"),
      makePage("Project usage", "projects"),
      makePage("Workspaces", "projects"),
    ],
  },
  {
    title: "Build & deploy",
    slug: "/build-deploy",
    content: [
      makePage("Services", undefined, "/services"),
      makePage("Environments", undefined, "/environments"),
      {
        subTitle: makePage("Variables", undefined, "/variables"),
        pages: [makePage("Reference", "variables")],
      },
      makePage("Feature flags", undefined, "/feature-flags"),
      makePage("Cron jobs", undefined, "/cron-jobs"),
      makePage("Functions", undefined, "/functions"),
      {
        subTitle: makePage("Sandboxes", undefined, "/sandboxes"),
        pages: [makePage("Quickstart", undefined, "/sandboxes/quickstart")],
      },
      {
        subTitle: makePage("Config as code", undefined, "/config-as-code"),
        pages: [makePage("Reference", "config-as-code")],
      },
      {
        subTitle: makePage("Infrastructure as Code (IaC)", undefined, "/infrastructure-as-code"),
        pages: [makePage("Reference", "infrastructure-as-code")],
      },
      {
        subTitle: makePage("Builds", undefined, "/builds"),
        pages: [
          makePage("Build configuration", "builds"),
          makePage("Build and start commands", "builds"),
          makePage("Skipped builds", "builds"),
          makePage("Dockerfiles", "builds"),
          makePage("Private registries", "builds"),
          makePage("Railpack", "builds"),
        ],
      },
      {
        subTitle: makePage("Deployments", undefined, "/deployments"),
        pages: [
          makePage("Pre-deploy command", "deployments"),
          makePage("Start command", "deployments"),
          makePage("Deployment actions", "deployments"),
          makePage("GitHub autodeploys", "deployments"),
          makePage("Image auto updates", "deployments"),
          makePage("Optimize performance", "deployments"),
          makePage("Healthchecks", "deployments"),
          makePage("Restart policy", "deployments"),
          makePage("Deployment teardown", "deployments"),
          makePage("Monorepo", "deployments"),
          makePage("Staged changes", "deployments"),
          makePage("Serverless", "deployments"),
          makePage("Regions", "deployments"),
          makePage("Scaling", "deployments"),
          makePage("Reference", "deployments"),
        ],
      },
      {
        subTitle: "Troubleshooting",
        pages: [
          makePage("Slow deployments", "deployments/troubleshooting"),
          makePage("NodeJS SIGTERM handling", "deployments/troubleshooting"),
          makePage(
            "No start command could be found",
            "deployments/troubleshooting",
          ),
        ],
      },
    ],
  },
  {
    title: "Data & storage",
    slug: "/data-storage",
    content: [
      {
        subTitle: makePage("Databases", undefined, "/databases"),
        pages: [
          makePage("Build a database service", "databases"),
          makePage("PostgreSQL", "databases"),
          makePage("PostgreSQL High Availability", "databases", "/databases/postgresql-ha"),
          makePage("PostgreSQL Connection Pooling", "databases", "/databases/postgresql-pgbouncer"),
          makePage("MySQL", "databases"),
          makePage("MySQL High Availability", "databases", "/databases/mysql-ha"),
          makePage("Redis", "databases"),
          makePage("Redis High Availability", "databases", "/databases/redis-ha"),
          makePage("MongoDB", "databases"),
          makePage("MongoDB High Availability", "databases", "/databases/mongo-ha"),
          makePage("Database view", "databases"),
          makePage("Reference", "databases"),
        ],
      },
      {
        subTitle: makePage("Volumes", undefined, "/volumes"),
        pages: [
          makePage("Backups", "volumes"),
          makePage("Point-in-Time Recovery", "volumes"),
          makePage("Reference", "volumes"),
        ],
      },
      {
        subTitle: makePage("Storage buckets", undefined, "/storage-buckets"),
        pages: [
          makePage(
            "Uploading & serving",
            "storage-buckets",
            "/storage-buckets/uploading-serving",
          ),
          makePage("Billing", "storage-buckets"),
        ],
      },
      {
        subTitle: "Troubleshooting",
        pages: [
          makePage(
            "Recover PostgreSQL from corrupted WAL",
            "databases/troubleshooting",
            "/databases/troubleshooting/postgres-corrupted-wal",
          ),
          makePage(
            "ENOTFOUND redis.railway.internal",
            "databases/troubleshooting",
          ),
        ],
      },
    ],
  },
  {
    title: "Networking",
    slug: "/networking",
    content: [
      {
        subTitle: makePage(
          "Public networking",
          undefined,
          "/networking/public-networking",
        ),
        pages: [
          makePage(
            "Specs & limits",
            "networking/public-networking",
            "/networking/public-networking/specs-and-limits",
          ),
        ],
      },
      {
        subTitle: makePage(
          "Private networking",
          undefined,
          "/networking/private-networking",
        ),
        pages: [
          makePage("Library configuration", "networking/private-networking"),
        ],
      },
      {
        subTitle: makePage("Domains", undefined, "/networking/domains"),
        pages: [
          makePage("Working with Domains", "networking/domains"),
          makePage("Railway Domains", "networking/domains"),
        ],
      },
      makePage("TCP proxy", "networking"),
      makePage("Outbound networking", "networking"),
      makePage("Static outbound IPs", "networking"),
      makePage("Edge networking", "networking"),
      makePage("CDN", "networking", "/networking/cdn"),
      makePage("WAF", "networking", "/networking/waf"),
      makePage("Edge rules", "networking"),
      {
        subTitle: "Troubleshooting",
        pages: [
          makePage("SSL", "networking/troubleshooting"),
          makePage("Network diagnostics", "networking/troubleshooting"),
          makePage(
            "Application failed to respond",
            "networking/troubleshooting",
          ),
          makePage("405 method not allowed", "networking/troubleshooting"),
        ],
      },
    ],
  },
  {
    title: "Observability",
    slug: "/observability",
    content: [
      makePage("Logs", "observability"),
      makePage("Metrics", "observability"),
      {
        subTitle: makePage("Tracing", undefined, "/observability/tracing"),
        pages: [
          makePage("Automatic instrumentation", "observability/tracing"),
          makePage("Node.js", "observability/tracing", "/observability/tracing/nodejs"),
          makePage("Deno", "observability/tracing"),
          makePage("Functions", "observability/tracing"),
          makePage("Python", "observability/tracing"),
          makePage("Go", "observability/tracing"),
          makePage("Java", "observability/tracing"),
          makePage("Ruby", "observability/tracing"),
          makePage(".NET", "observability/tracing", "/observability/tracing/dotnet"),
          makePage("Rust", "observability/tracing"),
          makePage("PHP", "observability/tracing"),
        ],
      },
      makePage("Webhooks", "observability"),
    ],
  },
  {
    title: "Access",
    slug: "/access",
    content: [
      makePage("Accounts", "access"),
      makePage("Two-factor enforcement", "access"),
      makePage("Multi-factor authentication", "access"),
    ],
  },
  {
    title: "Integrations",
    slug: "/integrations",
    content: [
      {
        subTitle: makePage("OAuth", undefined, "/integrations/oauth"),
        pages: [
          makePage("Quickstart", "integrations/oauth"),
          makePage("Creating an app", "integrations/oauth"),
          makePage(
            "Login & tokens",
            "integrations/oauth",
            "/integrations/oauth/login-and-tokens",
          ),
          makePage(
            "Scopes & user consent",
            "integrations/oauth",
            "/integrations/oauth/scopes-and-user-consent",
          ),
          makePage("Fetching workspaces or projects", "integrations/oauth"),
          makePage("Managing an app", "integrations/oauth"),
          makePage("Authorized apps", "integrations/oauth"),
          makePage("Troubleshooting", "integrations/oauth"),
        ],
      },
      {
        subTitle: makePage("API", undefined, "/integrations/api"),
        pages: [
          makePage(
            "Introduction to GraphQL",
            "integrations/api",
            "/integrations/api/graphql-overview",
          ),
          makePage("API cookbook", "integrations/api"),
          makePage("Manage projects", "integrations/api"),
          makePage("Manage services", "integrations/api"),
          makePage("Manage deployments", "integrations/api"),
          makePage("Manage variables", "integrations/api"),
          makePage("Manage environments", "integrations/api"),
          makePage("Manage domains", "integrations/api"),
          makePage("Manage volumes", "integrations/api"),
        ],
      },
      {
        subTitle: makePage("Stripe Provisioning", undefined, "/integrations/stripe"),
        pages: [],
      },
    ],
  },
  {
    title: "Community",
    slug: "/community",
    content: [
      makePage("The Conductor program", "community"),
      makePage("Affiliate program", "community"),
      makePage("Bounties", "community"),
    ],
  },
];
